package com.example.kerjain.ui.lowongan

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView // PENTING: Import TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.JobDetailActivity
import com.example.kerjain.R
import com.example.kerjain.ui.home.JobAdapter

class LowonganFragment : Fragment() {

    private lateinit var viewModel: LowonganViewModel
    private lateinit var rvLowongan: RecyclerView
    private lateinit var progressBar: ProgressBar

    private lateinit var tvJobCount: TextView

    private lateinit var adapter: JobAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_lowongan_pelamar, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rvLowongan = view.findViewById(R.id.rvLowongan)
        progressBar = view.findViewById(R.id.progressBar)
        tvJobCount = view.findViewById(R.id.tvJobCount)

        viewModel = ViewModelProvider(this)[LowonganViewModel::class.java]

        setupRecyclerView()
        observeData()
    }

    private fun setupRecyclerView() {
        adapter = JobAdapter { lowongan ->
            val intent = Intent(requireContext(), JobDetailActivity::class.java)
            intent.putExtra("JOB_ID", lowongan.job_id)
            startActivity(intent)
        }

        rvLowongan.layoutManager = LinearLayoutManager(context)
        rvLowongan.adapter = adapter
    }

    private fun observeData() {
        progressBar.visibility = View.VISIBLE

        viewModel.lowongans.observe(viewLifecycleOwner) { listLowongan ->
            progressBar.visibility = View.GONE

            if (listLowongan != null) {
                adapter.setItems(listLowongan)

                val count = listLowongan.size
                tvJobCount.text = "Menampilkan $count lowongan"

            } else {
                Toast.makeText(context, "Gagal memuat data", Toast.LENGTH_SHORT).show()
                tvJobCount.text = "Menampilkan 0 lowongan"
            }
        }
    }

    override fun onResume() {
        super.onResume()

    }
}