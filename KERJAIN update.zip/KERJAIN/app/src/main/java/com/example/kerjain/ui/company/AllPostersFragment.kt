package com.example.kerjain.ui.company

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.R
import com.example.kerjain.data.Poster
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class AllPostersFragment : Fragment() {

    private lateinit var rvPosters: RecyclerView
    private lateinit var adapter: PosterCompanyAdapter

    private val posters = mutableListOf<Poster>()
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_all_posters, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val btnBack = view.findViewById<ImageView>(R.id.btnBack)
        rvPosters = view.findViewById(R.id.rvPosters)

        btnBack.setOnClickListener {
            findNavController().navigateUp()
        }

        setupRecyclerView()
        loadAllCompanyPosters()
    }

    private fun setupRecyclerView() {
        adapter = PosterCompanyAdapter(posters)
        rvPosters.layoutManager = GridLayoutManager(requireContext(), 2)
        rvPosters.adapter = adapter
    }

    private fun loadAllCompanyPosters() {
        val companyId = auth.currentUser?.uid
        if (companyId == null) {
            Toast.makeText(context, "User tidak login", Toast.LENGTH_SHORT).show()
            return
        }

        db.collection("posters")
            .whereEqualTo("companyId", companyId)
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Toast.makeText(context, "Gagal memuat poster", Toast.LENGTH_SHORT).show()
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    posters.clear()
                    for (doc in snapshot) {
                        posters.add(doc.toObject(Poster::class.java))
                    }
                    adapter.notifyDataSetChanged()
                }
            }
    }
}