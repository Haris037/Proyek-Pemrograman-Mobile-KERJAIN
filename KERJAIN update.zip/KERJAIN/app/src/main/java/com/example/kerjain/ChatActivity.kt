package com.example.kerjain

import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.data.Message
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class ChatActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var rvChatMessages: RecyclerView
    private lateinit var etMessage: EditText
    private lateinit var btnSendMessage: ImageButton

    private lateinit var tvChatName: TextView
    private lateinit var ivProfileChat: ImageView

    private val auth = Firebase.auth
    private val db = Firebase.firestore
    private lateinit var messageAdapter: MessageAdapter

    private var recipientId: String? = null
    private var recipientName: String? = null
    private var senderId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        recipientId = intent.getStringExtra("RECIPIENT_ID")
        recipientName = intent.getStringExtra("RECIPIENT_NAME")
        senderId = auth.currentUser?.uid

        if (recipientId == null || senderId == null) {
            Toast.makeText(this, "Data chat error: ID Kosong", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        bindViews()
        setupToolbar()
        setupRecyclerView()
        setupListeners()

        if (recipientName != null) {
            tvChatName.text = recipientName
        } else {
            tvChatName.text = "Memuat..."
            fetchRecipientInfo()
        }

        listenForMessages()
    }

    private fun bindViews() {
        toolbar = findViewById(R.id.toolbar)
        rvChatMessages = findViewById(R.id.rvChatMessages)
        etMessage = findViewById(R.id.etMessage)
        btnSendMessage = findViewById(R.id.btnSendMessage)

        tvChatName = findViewById(R.id.tvChatName)
        ivProfileChat = findViewById(R.id.ivProfileChat)
    }

    private fun setupToolbar() {
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }
    }

    private fun setupRecyclerView() {
        messageAdapter = MessageAdapter(mutableListOf(), senderId!!)
        rvChatMessages.apply {
            adapter = messageAdapter
            layoutManager = LinearLayoutManager(this@ChatActivity).apply {
                stackFromEnd = true
            }
        }
    }

    private fun setupListeners() {
        btnSendMessage.setOnClickListener {
            val messageText = etMessage.text.toString().trim()
            if (messageText.isNotEmpty()) {
                sendMessage(messageText)
            }
        }
    }

    private fun fetchRecipientInfo() {
        db.collection("perusahaan").document(recipientId!!).get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val name = document.getString("nama_perusahaan")
                    tvChatName.text = name
                    recipientName = name
                    ivProfileChat.setImageResource(R.drawable.company_placeholder)
                } else {
                    db.collection("pelamar").document(recipientId!!).get()
                        .addOnSuccessListener { doc ->
                            if (doc.exists()) {
                                val name = doc.getString("nama")
                                tvChatName.text = name
                                recipientName = name
                                ivProfileChat.setImageResource(R.drawable.bg_avatar_circle)
                            }
                        }
                }
            }
    }

    private fun getChatRoomId(user1: String, user2: String): String {
        return if (user1 < user2) "${user1}_${user2}" else "${user2}_${user1}"
    }

    private fun listenForMessages() {
        val chatRoomId = getChatRoomId(senderId!!, recipientId!!)
        db.collection("chats").document(chatRoomId).collection("messages")
            .orderBy("timestamp")
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Log.e("ChatActivity", "Listen failed.", e)
                    return@addSnapshotListener
                }

                val messages = snapshot?.toObjects(Message::class.java)
                if (messages != null) {
                    messageAdapter.updateMessages(messages)
                    if (messageAdapter.itemCount > 0) {
                        rvChatMessages.scrollToPosition(messageAdapter.itemCount - 1)
                    }
                }
            }
    }

    private fun sendMessage(messageText: String) {
        val chatRoomId = getChatRoomId(senderId!!, recipientId!!)
        val timestamp = System.currentTimeMillis()

        etMessage.text.clear()

        val message = Message(
            senderId = senderId!!,
            receiverId = recipientId!!,
            message = messageText,
            timestamp = timestamp
        )

        db.collection("chats").document(chatRoomId).collection("messages")
            .add(message)
            .addOnSuccessListener {
                Log.d("ChatActivity", "Pesan terkirim")
            }
            .addOnFailureListener { e ->
                Log.e("ChatActivity", "Gagal kirim pesan", e)
                Toast.makeText(this, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
            }

        val conversationData = hashMapOf(
            "participants" to listOf(senderId, recipientId),
            "lastMessage" to messageText,
            "timestamp" to timestamp,
            "users" to mapOf(
                senderId!! to true,
                recipientId!! to true
            )
        )

        db.collection("conversations").document(chatRoomId)
            .set(conversationData)
            .addOnFailureListener { e ->
                Log.e("ChatActivity", "Gagal update conversation", e)
            }
    }
}