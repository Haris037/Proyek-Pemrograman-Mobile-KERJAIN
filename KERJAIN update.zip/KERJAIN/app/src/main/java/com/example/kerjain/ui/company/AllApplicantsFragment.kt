package com.example.kerjain.ui.company

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView // Atau Button / ImageButton sesuai XML
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController // TAMBAHAN: Import ini penting
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.R
import com.example.kerjain.data.Lamaran
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class AllApplicantsFragment : Fragment() {

    private val db = Firebase.firestore
    private val auth = Firebase.auth
    private lateinit var rvApplicants: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var emptyStateLayout: LinearLayout
    private lateinit var btnBack: View

    private val applicantList = mutableListOf<Lamaran>()
    private lateinit var adapter: AllApplicantsAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_all_applicants, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rvApplicants = view.findViewById(R.id.rvAllApplicants)
        progressBar = view.findViewById(R.id.progressBar)
        emptyStateLayout = view.findViewById(R.id.emptyStateLayout)

        btnBack = view.findViewById(R.id.btnBack)

        btnBack.setOnClickListener {
            findNavController().navigateUp()
        }

        setupRecyclerView()
        loadApplicants()
    }

    private fun setupRecyclerView() {
        adapter = AllApplicantsAdapter(applicantList)
        rvApplicants.layoutManager = LinearLayoutManager(context)
        rvApplicants.adapter = adapter
    }

    private fun loadApplicants() {
        progressBar.visibility = View.VISIBLE
        val companyId = auth.currentUser?.uid

        if (companyId == null) {
            progressBar.visibility = View.GONE
            emptyStateLayout.visibility = View.VISIBLE
            Toast.makeText(context, "Gagal mendapatkan ID perusahaan", Toast.LENGTH_SHORT).show()
            return
        }

        db.collection("lowongan")
            .whereEqualTo("perusahaan_id", companyId)
            .get()
            .addOnSuccessListener { jobDocuments ->
                if (jobDocuments.isEmpty) {
                    progressBar.visibility = View.GONE
                    emptyStateLayout.visibility = View.VISIBLE
                    return@addOnSuccessListener
                }

                val jobIds = jobDocuments.map { it.id }

                db.collection("lamaran")
                    .whereIn("job_id", jobIds)
                    .get()
                    .addOnSuccessListener { applicationDocuments ->
                        if (applicationDocuments.isEmpty) {
                            progressBar.visibility = View.GONE
                            emptyStateLayout.visibility = View.VISIBLE
                        } else {
                            val applications = applicationDocuments.toObjects(Lamaran::class.java)
                            applicantList.clear()
                            applicantList.addAll(applications)
                            adapter.notifyDataSetChanged()

                            progressBar.visibility = View.GONE
                            emptyStateLayout.visibility = if (applicantList.isEmpty()) View.VISIBLE else View.GONE
                            rvApplicants.visibility = if (applicantList.isNotEmpty()) View.VISIBLE else View.GONE
                        }
                    }
                    .addOnFailureListener { e ->
                        progressBar.visibility = View.GONE
                        emptyStateLayout.visibility = View.VISIBLE
                        Toast.makeText(context, "Error getting applications: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
            }
            .addOnFailureListener { e ->
                progressBar.visibility = View.GONE
                emptyStateLayout.visibility = View.VISIBLE
                Toast.makeText(context, "Error getting jobs: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}