package com.example.kerjain.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "lamaran")
data class Lamaran(
    @PrimaryKey(autoGenerate = true)
    val lamaran_id: Int = 0,
    val pelamar_id: String? = null,
    val job_id: String? = null,
    val status_lamaran: String? = null,
    val tanggal_lamaran: Long? = null
) {
    // Diperlukan untuk deserialisasi Firestore
    constructor() : this(0, null, null, null, null)
}
