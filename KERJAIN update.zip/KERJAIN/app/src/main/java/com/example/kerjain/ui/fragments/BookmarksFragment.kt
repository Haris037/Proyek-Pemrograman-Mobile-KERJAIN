package com.example.kerjain.ui.fragments

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.R
import com.example.kerjain.data.Bookmark // Pastikan Anda mengimpor data class yang benar
import com.example.kerjain.ui.adapters.BookmarksAdapter
import com.example.kerjain.ui.viewmodel.MainListViewModel
import com.google.android.material.snackbar.Snackbar

class BookmarksFragment : Fragment(R.layout.activity_bookmark) {

    private val vm: MainListViewModel by activityViewModels()
    private lateinit var adapter: BookmarksAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val rv = view.findViewById<RecyclerView>(R.id.rvBookmarks)
        val btnBack = view.findViewById<ImageView>(R.id.btnBackBookmark)
        val btnDeleteAll = view.findViewById<ImageView>(R.id.btnDeleteAllBookmarks)
        val empty = view.findViewById<View>(R.id.emptyState)

        adapter = BookmarksAdapter(
            mutableListOf(),
            onOpen = { /* handle open action */ },
            onRemove = { bookmark -> vm.deleteBookmark(bookmark) }
        )

        rv.layoutManager = LinearLayoutManager(requireContext())
        rv.adapter = adapter

        val touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT) {
            override fun onMove(rv: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder) = false
            
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                // --- PERBAIKAN DI SINI ---
                // Menggunakan 'adapterPosition' yang lebih kompatibel
                val position = viewHolder.adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    try {
                        val removedBookmark = adapter.items[position]
                        vm.deleteBookmark(removedBookmark)

                        Snackbar.make(viewHolder.itemView, "Bookmark dihapus", Snackbar.LENGTH_LONG)
                            .setAction("Batal") {
                                vm.addBookmark(removedBookmark)
                            }.show()
                    } catch (e: IndexOutOfBoundsException) {
                        Log.w("BookmarksFragment", "Item di posisi $position sudah tidak ada saat di-swipe.")
                    }
                }
            }
        })
        touchHelper.attachToRecyclerView(rv)

        vm.bookmarks.observe(viewLifecycleOwner) { bookmarks ->
            adapter.submitList(bookmarks)
            empty.visibility = if (bookmarks.isEmpty()) View.VISIBLE else View.GONE
        }

        btnBack.setOnClickListener { requireActivity().onBackPressed() }

        btnDeleteAll.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Hapus Semua Bookmark")
                .setMessage("Yakin ingin menghapus semua bookmark?")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Hapus") { _, _ -> vm.clearBookmarks() }
                .show()
        }
    }
}