package com.example.kerjain.ui.company_poster

class Company_poster {
}