package com.example.kerjain.ui.company

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.ChatActivity
import com.example.kerjain.R
import com.example.kerjain.ui.chat.ChatItem
import com.example.kerjain.ui.chat.ChatListAdapter
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase

class ChatCompanyFragment : Fragment() {

    private lateinit var rvChats: RecyclerView
    private lateinit var emptyStateLayout: LinearLayout
    private lateinit var adapter: ChatListAdapter

    private val db = FirebaseFirestore.getInstance()
    private val auth = Firebase.auth

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_chat_company, container, false)

        rvChats = root.findViewById(R.id.rvChats)
        emptyStateLayout = root.findViewById(R.id.emptyStateLayout)

        setupRecyclerView()
        loadConversations()

        return root
    }

    private fun setupRecyclerView() {
        adapter = ChatListAdapter(emptyList()) { item ->
            val intent = Intent(requireContext(), ChatActivity::class.java)

            intent.putExtra("RECIPIENT_ID", item.otherUserId)
            intent.putExtra("RECIPIENT_NAME", item.name)

            startActivity(intent)
        }

        rvChats.layoutManager = LinearLayoutManager(requireContext())
        rvChats.adapter = adapter
    }

    private fun loadConversations() {
        val currentUserId = auth.currentUser?.uid ?: return

        db.collection("conversations")
            .whereArrayContains("participants", currentUserId)
            .addSnapshotListener { snapshot, e ->
                if (e != null) return@addSnapshotListener

                if (snapshot != null && !snapshot.isEmpty) {
                    val chatItems = mutableListOf<ChatItem>()
                    val totalDocs = snapshot.documents.size
                    var processedDocs = 0

                    for (doc in snapshot.documents) {
                        val participants = doc.get("participants") as? List<String> ?: continue
                        val lastMessage = doc.getString("lastMessage") ?: ""
                        val timestamp = doc.getLong("timestamp") ?: 0L

                        val otherUserId = participants.firstOrNull { it != currentUserId } ?: continue

                        fetchApplicantName(otherUserId) { name ->
                            chatItems.add(
                                ChatItem(
                                    conversationId = doc.id,
                                    otherUserId = otherUserId,
                                    name = name,
                                    lastMessage = lastMessage,
                                    timestamp = timestamp
                                )
                            )

                            processedDocs++
                            if (processedDocs == totalDocs) {
                                chatItems.sortByDescending { it.timestamp }
                                updateUI(chatItems)
                            }
                        }
                    }
                } else {
                    updateUI(emptyList())
                }
            }
    }

    private fun fetchApplicantName(userId: String, callback: (String) -> Unit) {
        db.collection("pelamar").document(userId).get()
            .addOnSuccessListener { doc ->
                if (doc.exists()) {
                    val namaPelamar = doc.getString("nama") ?: "Pelamar Tanpa Nama"
                    callback(namaPelamar)
                } else {
                    callback("User Tidak Dikenal")
                }
            }
    }

    private fun updateUI(items: List<ChatItem>) {
        if (items.isEmpty()) {
            emptyStateLayout.visibility = View.VISIBLE
            rvChats.visibility = View.GONE
        } else {
            emptyStateLayout.visibility = View.GONE
            rvChats.visibility = View.VISIBLE
            adapter.updateData(items)
        }
    }
}