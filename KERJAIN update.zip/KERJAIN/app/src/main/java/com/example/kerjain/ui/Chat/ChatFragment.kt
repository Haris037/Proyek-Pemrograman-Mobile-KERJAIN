package com.example.kerjain.ui.chat

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.ChatActivity
import com.example.kerjain.ChatHistoryAdapter
import com.example.kerjain.R
import com.example.kerjain.data.Conversation
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class ChatFragment : Fragment() {

    private lateinit var rvChats: RecyclerView
    private lateinit var emptyStateLayout: LinearLayout
    private lateinit var adapter: ChatHistoryAdapter

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_chat_pelamar, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rvChats = view.findViewById(R.id.rvChats)
        emptyStateLayout = view.findViewById(R.id.emptyStateLayout)

        setupRecyclerView()
        loadConversations()
    }

    private fun setupRecyclerView() {
        val currentUserId = auth.currentUser?.uid ?: return

        adapter = ChatHistoryAdapter(mutableListOf(), currentUserId) { conversation, otherUserId ->
            val intent = Intent(context, ChatActivity::class.java)
            intent.putExtra("RECIPIENT_ID", otherUserId)
            startActivity(intent)
        }

        rvChats.layoutManager = LinearLayoutManager(context)
        rvChats.adapter = adapter
    }

    private fun loadConversations() {
        val currentUserId = auth.currentUser?.uid ?: return

        db.collection("conversations")
            .whereArrayContains("participants", currentUserId)
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshots, e ->
                if (e != null) {
                    return@addSnapshotListener
                }

                if (snapshots != null && !snapshots.isEmpty) {
                    val list = snapshots.documents.mapNotNull { doc ->
                        val conv = doc.toObject(Conversation::class.java)
                        conv?.id = doc.id
                        conv
                    }

                    adapter.setItems(list)
                    rvChats.visibility = View.VISIBLE
                    emptyStateLayout.visibility = View.GONE
                } else {
                    rvChats.visibility = View.GONE
                    emptyStateLayout.visibility = View.VISIBLE
                }
            }
    }
}