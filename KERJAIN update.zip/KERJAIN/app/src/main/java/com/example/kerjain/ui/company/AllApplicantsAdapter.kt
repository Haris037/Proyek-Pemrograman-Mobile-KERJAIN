package com.example.kerjain.ui.company

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.R
import com.example.kerjain.data.Lamaran
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class AllApplicantsAdapter(private val applicants: List<Lamaran>) : RecyclerView.Adapter<AllApplicantsAdapter.ViewHolder>() {

    private val db = Firebase.firestore

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val applicantName: TextView = view.findViewById(R.id.tvApplicantName)
        val appliedFor: TextView = view.findViewById(R.id.tvAppliedFor)
        val applicantImage: ImageView = view.findViewById(R.id.ivApplicantImage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_applicant, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val application = applicants[position]

        application.pelamar_id?.let { pelamarId ->
            db.collection("pelamar").document(pelamarId.toString()).get()
                .addOnSuccessListener { document ->
                    holder.applicantName.text = document.getString("username") ?: "Username Tidak Tersedia"
                }
                .addOnFailureListener {
                    holder.applicantName.text = "Gagal memuat nama"
                }
        }

        application.job_id?.let { jobId ->
            db.collection("lowongan").document(jobId.toString()).get()
                .addOnSuccessListener { document ->
                    holder.appliedFor.text = "Melamar untuk: ${document.getString("judul") ?: "Posisi Tidak Diketahui"}"
                }
                .addOnFailureListener {
                    holder.appliedFor.text = "Gagal memuat posisi"
                }
        }

        holder.applicantImage.setImageResource(R.drawable.ic_profile_placeholder)
    }

    override fun getItemCount() = applicants.size
}
