package com.example.kerjain.ui.home

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import com.example.kerjain.R
import com.example.kerjain.data.Lowongan
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObject
import com.google.firebase.ktx.Firebase

class HomeViewModel(private val savedStateHandle: SavedStateHandle) : ViewModel() {

    private val _categories = MutableLiveData<List<JobCategory>>()
    val categories: LiveData<List<JobCategory>> get() = _categories

    private val _recommended = MutableLiveData<List<Lowongan>>()
    val recommended: LiveData<List<Lowongan>> get() = _recommended

    private val _locations = MutableLiveData<List<String>>()
    val locations: LiveData<List<String>> get() = _locations

    private var cachedRecommended: List<Lowongan> = emptyList()

    private val db = Firebase.firestore

    companion object {
        val DEFAULT_CATEGORIES = listOf(
            JobCategory("Admin", R.drawable.admin),
            JobCategory("Sekretaris", R.drawable.secretary),
            JobCategory("Customer Service", R.drawable.cs),

            JobCategory("Akuntansi", R.drawable.accounting),
            JobCategory("Keuangan", R.drawable.finance),

            JobCategory("Programmer", R.drawable.programmer),
            JobCategory("Web Developer", R.drawable.web),
            JobCategory("Mobile Developer", R.drawable.mobile),
            JobCategory("Data Analyst", R.drawable.data_analyst),

            JobCategory("Content Creator", R.drawable.content),
            JobCategory("Desain Grafis", R.drawable.design),
            JobCategory("Fotografer", R.drawable.camera),

            JobCategory("Guru", R.drawable.teacher),
            JobCategory("Dosen", R.drawable.lecturer),

            JobCategory("Perawat", R.drawable.nurse),
            JobCategory("Apoteker", R.drawable.pharmacy),

            JobCategory("Resepsionis", R.drawable.receptionist),
            JobCategory("Housekeeping", R.drawable.housekeeping),

            JobCategory("Chef", R.drawable.chef),
            JobCategory("Barista", R.drawable.barista),
            JobCategory("Waiter", R.drawable.waiter),

            JobCategory("Kurir", R.drawable.courier),
            JobCategory("Logistik", R.drawable.logistics),

            JobCategory("Security", R.drawable.security),
            JobCategory("Mekanik", R.drawable.mechanic),

            JobCategory("Quality Control", R.drawable.qc),
            JobCategory("Staff Gudang", R.drawable.warehouse),

            JobCategory("Freelancer", R.drawable.freelance),
        )
        private val MAIN_CATEGORIES = DEFAULT_CATEGORIES.map { it.name }.filter { it != "Semua" && it != "Lainnya" }

        val STATIC_LOCATIONS = listOf(
            "Seluruh Indonesia",
            "Jakarta Pusat",
            "Jakarta Selatan",
            "Jakarta Barat",
            "Jakarta Timur",
            "Jakarta Utara",
            "Bogor",
            "Depok",
            "Tangerang",
            "Tangerang Selatan"
        )
    }

    init {
        _categories.value = DEFAULT_CATEGORIES
        _locations.value = STATIC_LOCATIONS
        loadJobsFromFirestore()
    }

    fun loadJobsFromFirestore() {
        db.collection("lowongan")
            .get()
            .addOnSuccessListener { result ->
                val jobList = mutableListOf<Lowongan>()
                for (document in result.documents) {
                    try {
                        val job = document.toObject<Lowongan>()
                        if (job != null) {
                            jobList.add(job.copy(job_id = document.id))
                        }
                    } catch (e: Exception) {
                        Log.e("HomeViewModel", "Gagal mem-parsing dokumen ${document.id}", e)
                    }
                }
                cachedRecommended = jobList
                _recommended.value = jobList
            }
            .addOnFailureListener { exception ->
                Log.w("HomeViewModel", "Gagal mendapatkan koleksi lowongan.", exception)
                _recommended.value = emptyList()
            }
    }

    fun filterJobsByCategory(category: String?) {
        when (category) {
            null, "Semua" -> {
                _recommended.value = cachedRecommended
            }
            "Lainnya" -> {
                val otherJobs = cachedRecommended.filter { it.category !in MAIN_CATEGORIES }
                _recommended.value = otherJobs
            }
            else -> {
                val categoryJobs = cachedRecommended.filter { it.category == category }
                _recommended.value = categoryJobs
            }
        }
    }

    fun filterJobsByLocation(location: String?) {
        if (location.isNullOrBlank() || location == "Seluruh Indonesia") {
            _recommended.value = cachedRecommended
            return
        }
        val filtered = cachedRecommended.filter {
            it.lokasi?.contains(location, ignoreCase = true) == true
        }
        _recommended.value = filtered
    }

    fun filterRecommended(query: String) {
        if (query.isBlank()) {
            _recommended.value = cachedRecommended
            return
        }
        val q = query.lowercase().trim()
        val filtered = cachedRecommended.filter { l ->
            l.judul.orEmpty().lowercase().contains(q) ||
            l.lokasi.orEmpty().lowercase().contains(q) ||
            l.gaji.orEmpty().lowercase().contains(q)
        }
        _recommended.value = filtered
    }
}
