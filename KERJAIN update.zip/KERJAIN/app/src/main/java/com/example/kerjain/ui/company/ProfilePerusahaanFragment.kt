package com.example.kerjain.ui.company

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.kerjain.WelcomeActivity
import com.example.kerjain.databinding.FragmentProfileCompanyBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ProfilePerusahaanFragment : Fragment() {

    private var _binding: FragmentProfileCompanyBinding? = null
    private val binding get() = _binding!!

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileCompanyBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        loadUserProfile()

        binding.btnLogout.setOnClickListener {
            auth.signOut()

            val intent = Intent(requireActivity(), WelcomeActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            requireActivity().finish()
        }
    }

    private fun loadUserProfile() {
        val userId = auth.currentUser?.uid

        if (userId != null) {
            db.collection("perusahaan").document(userId)
                .get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val companyName = document.getString("nama_perusahaan")
                        val companyEmail = document.getString("email")
                        binding.tvCompanyName.text = companyName ?: "Nama Perusahaan"
                        binding.tvCompanyEmail.text = companyEmail ?: "email@perusahaan.com"

                    }
                }
                .addOnFailureListener { e ->
                    Toast.makeText(context, "Gagal memuat profil: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}