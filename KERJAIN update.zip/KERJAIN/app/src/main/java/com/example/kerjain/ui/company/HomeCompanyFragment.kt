package com.example.kerjain.ui.company

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class HomeCompanyFragment : Fragment() {
    private lateinit var tvCompanyName: TextView
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_home_company, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        tvCompanyName = view.findViewById(R.id.tvCompanyName)

        val btnAddJob = view.findViewById<Button>(R.id.btnAddJob)
        val tvSeeAllPosters = view.findViewById<TextView>(R.id.tvSeeAllPosters)
        val tvSeeAllWorkers = view.findViewById<TextView>(R.id.tvSeeAllWorkers)
        val rvCompanyPosters = view.findViewById<RecyclerView>(R.id.rvCompanyPosters)
        val rvWorkers = view.findViewById<RecyclerView>(R.id.rvWorkers)

        loadCompanyProfile()

        btnAddJob.setOnClickListener {
            findNavController().navigate(R.id.action_navigation_home_company_to_addJobFragment)
        }

        tvSeeAllPosters.setOnClickListener {
            findNavController().navigate(R.id.action_navigation_home_company_to_allPostersFragment)
        }

        tvSeeAllWorkers.setOnClickListener {
            findNavController().navigate(R.id.action_navigation_home_company_to_allApplicantsFragment)
        }
    }

    private fun loadCompanyProfile() {
        val currentUser = auth.currentUser
        if (currentUser == null) return

        val uid = currentUser.uid

        db.collection("perusahaan").document(uid).get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val name = document.getString("nama_perusahaan")

                    tvCompanyName.text = "Halo, ${name ?: "Perusahaan"}"
                } else {
                    Log.d("HomeFragment", "Dokumen perusahaan tidak ditemukan")
                }
            }
            .addOnFailureListener { exception ->
                Log.e("HomeFragment", "Gagal mengambil data: ", exception)
                context?.let {
                    Toast.makeText(it, "Gagal memuat profil", Toast.LENGTH_SHORT).show()
                }
            }
    }
}