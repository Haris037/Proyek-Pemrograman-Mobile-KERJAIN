package com.example.kerjain.ui.chat

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.R
import java.text.SimpleDateFormat
import java.util.*

data class ChatItem(
    val conversationId: String,
    val otherUserId: String,
    val name: String,
    val lastMessage: String,
    val timestamp: Long,
    val image: String? = null
)

class ChatListAdapter(
    private var items: List<ChatItem>,
    private val onClick: (ChatItem) -> Unit
) : RecyclerView.Adapter<ChatListAdapter.VH>() {

    inner class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivLogo: ImageView = itemView.findViewById(R.id.ivCompanyLogo)
        val tvName: TextView = itemView.findViewById(R.id.tvCompanyName)
        val tvMessage: TextView = itemView.findViewById(R.id.tvLastMessage)
        val tvTime: TextView = itemView.findViewById(R.id.tvTime)

        init {
            itemView.setOnClickListener { onClick(items[adapterPosition]) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_chat, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]

        holder.tvName.text = item.name
        holder.tvMessage.text = item.lastMessage

        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        holder.tvTime.text = sdf.format(Date(item.timestamp))

        holder.ivLogo.setImageResource(R.drawable.company_placeholder)
    }

    override fun getItemCount(): Int = items.size

    fun updateData(newItems: List<ChatItem>) {
        items = newItems
        notifyDataSetChanged()
    }
}