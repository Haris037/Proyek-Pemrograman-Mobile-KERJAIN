package com.example.kerjain.ui.company

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.cloudinary.android.MediaManager
import com.cloudinary.android.callback.ErrorInfo
import com.cloudinary.android.callback.UploadCallback
import com.example.kerjain.databinding.FragmentAddPosterBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

class AddPosterFragment : Fragment() {

    private var _binding: FragmentAddPosterBinding? = null
    private val binding get() = _binding!!

    private var imageUri: Uri? = null
    private var isUploading = false

    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }

    companion object {
        private const val REQUEST_CODE_IMAGE_PICKER = 100
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAddPosterBinding.inflate(inflater, container, false)
        initCloudinary()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnBack.setOnClickListener { findNavController().navigateUp() }
        binding.btnUploadPoster.setOnClickListener { openImagePicker() }
        binding.imgPoster.setOnClickListener { openImagePicker() }

        binding.btnPostPoster.setOnClickListener {
            if (!isUploading) publishPoster()
        }
    }

    private fun initCloudinary() {
        try {
            MediaManager.get()
        } catch (e: Exception) {
            val config = hashMapOf(
                "cloud_name" to "kerjain",
                "api_key" to "936223883875598"
            )
            MediaManager.init(requireContext().applicationContext, config)
        }
    }

    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_PICK).apply {
            type = "image/*"
        }
        startActivityForResult(intent, REQUEST_CODE_IMAGE_PICKER)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_IMAGE_PICKER && resultCode == Activity.RESULT_OK) {
            imageUri = data?.data
            binding.imgPoster.setImageURI(imageUri)
        }
    }

    private fun publishPoster() {
        val title = binding.etPosterTitle.text.toString().trim()
        val companyId = auth.currentUser?.uid

        if (companyId == null) {
            Toast.makeText(context, "User belum login", Toast.LENGTH_SHORT).show()
            return
        }

        if (title.isEmpty()) {
            binding.etPosterTitle.error = "Judul wajib diisi"
            return
        }

        if (imageUri == null) {
            Toast.makeText(context, "Pilih gambar terlebih dahulu", Toast.LENGTH_SHORT).show()
            return
        }

        isUploading = true
        binding.btnPostPoster.isEnabled = false
        binding.btnPostPoster.text = "Mengupload..."

        val cloudName = "kerjain"
        val uploadPreset = "kerjain"

        val inputStream = requireContext().contentResolver.openInputStream(imageUri!!)!!
        val bytes = inputStream.readBytes()

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart(
                "file",
                "poster.jpg",
                bytes.toRequestBody("image/*".toMediaType())
            )
            .addFormDataPart("upload_preset", uploadPreset)
            .build()

        val request = Request.Builder()
            .url("https://api.cloudinary.com/v1_1/$cloudName/image/upload")
            .post(requestBody)
            .build()

        OkHttpClient().newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                requireActivity().runOnUiThread {
                    resetButton()
                    Toast.makeText(context, "Upload gagal: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()
                if (!response.isSuccessful || body == null) {
                    requireActivity().runOnUiThread {
                        resetButton()
                        Toast.makeText(context, "Server error", Toast.LENGTH_LONG).show()
                    }
                    return
                }

                val json = JSONObject(body)
                val imageUrl = json.getString("secure_url")

                requireActivity().runOnUiThread {
                    saveToFirestore(title, imageUrl, companyId)
                }
            }
        })
    }


    private fun saveToFirestore(title: String, imageUrl: String, companyId: String) {
        val posterId = db.collection("posters").document().id

        val data = hashMapOf(
            "id" to posterId,
            "title" to title,
            "imageUrl" to imageUrl,
            "companyId" to companyId,
            "timestamp" to FieldValue.serverTimestamp()
        )

        db.collection("posters")
            .document(posterId)
            .set(data)
            .addOnSuccessListener {
                Toast.makeText(context, "Poster berhasil dipublish", Toast.LENGTH_SHORT).show()
                findNavController().navigateUp()
            }
            .addOnFailureListener {
                resetButton()
                Toast.makeText(context, "Gagal simpan data", Toast.LENGTH_SHORT).show()
            }
    }

    private fun resetButton() {
        isUploading = false
        binding.btnPostPoster.isEnabled = true
        binding.btnPostPoster.text = "Publish Poster"
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}