package com.example.kerjain.ui.company

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import com.example.kerjain.R
import com.example.kerjain.data.Poster
import com.example.kerjain.databinding.FragmentPosterCompanyBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class PosterCompanyFragment : Fragment() {

    private var _binding: FragmentPosterCompanyBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: PosterCompanyAdapter
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val postersList = mutableListOf<Poster>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPosterCompanyBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        loadMyPosters()

        binding.btnCreatePoster.setOnClickListener {
            findNavController().navigate(R.id.action_navigation_poster_company_to_addPosterFragment)
        }
    }

    private fun setupRecyclerView() {
        adapter = PosterCompanyAdapter(postersList)
        binding.rvPosters.layoutManager = GridLayoutManager(context, 2)
        binding.rvPosters.adapter = adapter
    }

    private fun loadMyPosters() {
        val myId = auth.currentUser?.uid
        if (myId == null) {
            Toast.makeText(context, "User tidak login", Toast.LENGTH_SHORT).show()
            return
        }

        db.collection("posters")
            .whereEqualTo("companyId", myId)
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshots, e ->
                if (e != null) {
                    Toast.makeText(context, "Gagal memuat data: ${e.message}", Toast.LENGTH_SHORT).show()
                    return@addSnapshotListener
                }

                if (snapshots != null) {
                    postersList.clear()
                    for (doc in snapshots) {
                        val poster = doc.toObject(Poster::class.java)
                        postersList.add(poster)
                    }
                    adapter.notifyDataSetChanged()

                    if (postersList.isEmpty()) {
                        binding.emptyState.visibility = View.VISIBLE
                        binding.rvPosters.visibility = View.GONE
                    } else {
                        binding.emptyState.visibility = View.GONE
                        binding.rvPosters.visibility = View.VISIBLE
                    }
                }
            }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}