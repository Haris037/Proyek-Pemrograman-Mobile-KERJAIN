package com.example.kerjain.data

import com.google.firebase.firestore.ServerTimestamp
import java.util.Date

data class Poster(
    var id: String = "",
    var imageUrl: String = "",
    var title: String = "",
    var companyId: String = "",
    @ServerTimestamp
    var timestamp: Date? = null
)