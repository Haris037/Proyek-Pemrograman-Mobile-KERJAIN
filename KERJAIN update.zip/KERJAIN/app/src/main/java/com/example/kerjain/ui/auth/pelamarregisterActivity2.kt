package com.example.kerjain.ui.auth

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.kerjain.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class pelamarregisterActivity2 : AppCompatActivity() {

    private lateinit var btnFinish: Button
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pelamarregister2)
        Log.d("REG_FLOW", "Memulai pelamarregisterActivity2 (Langkah 2)")

        auth = Firebase.auth
        db = Firebase.firestore
        btnFinish = findViewById(R.id.btnFinish)

        btnFinish.setOnClickListener {
            saveApplicantData()
        }
    }

    private fun saveApplicantData() {
        val user = auth.currentUser
        if (user == null) {
            Toast.makeText(this, "Sesi registrasi tidak valid.", Toast.LENGTH_SHORT).show()
            return
        }

        val username = intent.getStringExtra("reg_username")
        val email = intent.getStringExtra("reg_email")
        val phone = intent.getStringExtra("reg_phone")

        if (username == null || email == null) {
            Toast.makeText(this, "Data dari langkah 1 tidak ditemukan.", Toast.LENGTH_SHORT).show()
            return
        }

        // --- SOLUSI ANDA DITERAPKAN DI SINI ---
        val pelamarData = hashMapOf(
            "nama" to username,
            "email" to email,
            "telepon" to (phone ?: ""),
            "tipe_akun" to "pelamar", // Menambahkan tipe akun secara eksplisit
            "alamat" to "",
            "skill" to "",
            "pengalaman" to "",
            "foto" to ""
        )

        db.collection("pelamar").document(user.uid)
            .set(pelamarData)
            .addOnSuccessListener { 
                Log.d("REG_FLOW", "SUKSES: Data pelamar disimpan dengan tipe_akun='pelamar'.")
                Toast.makeText(this, "Registrasi Pelamar Berhasil!", Toast.LENGTH_LONG).show()
                auth.signOut()
                val intent = Intent(this, LoginPelamarActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
             }
            .addOnFailureListener { e -> 
                Log.e("REG_FLOW", "GAGAL menyimpan data pelamar: ${e.message}")
                Toast.makeText(this, "Gagal menyimpan profil: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }
}
