package com.example.kerjain.ui.home

import android.text.format.DateUtils
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.R
import com.example.kerjain.data.Lowongan
import com.example.kerjain.databinding.ItemJobcardBinding
import com.google.firebase.firestore.FirebaseFirestore
import java.text.NumberFormat
import java.util.Locale

class JobAdapter(
    private val items: MutableList<Lowongan> = mutableListOf(),
    private val onClick: (Lowongan) -> Unit
) : RecyclerView.Adapter<JobAdapter.VH>() {

    private val db = FirebaseFirestore.getInstance()

    inner class VH(val binding: ItemJobcardBinding) : RecyclerView.ViewHolder(binding.root) {
        init {
            binding.root.setOnClickListener {
                val pos = adapterPosition
                if (pos != RecyclerView.NO_POSITION) {
                    onClick(items[pos])
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemJobcardBinding.inflate(inflater, parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val job = items[position]

        holder.binding.tvJobTitle.text = job.judul ?: "Posisi Tidak Tersedia"
        holder.binding.tvLocation.text = job.lokasi ?: "Lokasi -"
        holder.binding.tvSalary.text = job.gaji ?: "Gaji disembunyikan"

        if (job.tanggal_post != null && job.tanggal_post > 0) {
            val timeAgo = DateUtils.getRelativeTimeSpanString(
                job.tanggal_post,
                System.currentTimeMillis(),
                DateUtils.MINUTE_IN_MILLIS
            )
        }

        val companyId = job.perusahaan_id
        if (!companyId.isNullOrEmpty()) {
            holder.binding.tvCompanyName.text = "Memuat..."
            holder.binding.ivCompanyLogo.setImageResource(R.drawable.company_placeholder)

            db.collection("perusahaan").document(companyId).get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val name = document.getString("nama_perusahaan")
                        holder.binding.tvCompanyName.text = name ?: "Perusahaan"
                    } else {
                        holder.binding.tvCompanyName.text = "Perusahaan Tidak Dikenal"
                    }
                }
                .addOnFailureListener {
                    holder.binding.tvCompanyName.text = "Perusahaan"
                }
        } else {
            holder.binding.tvCompanyName.text = "Perusahaan"
            holder.binding.ivCompanyLogo.setImageResource(R.drawable.company_placeholder)
        }
    }

    override fun getItemCount(): Int = items.size

    fun setItems(newItems: List<Lowongan>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    fun sort(criteria: String, ascending: Boolean) {
        val comparator = when (criteria) {
            "date" -> compareBy<Lowongan> { it.tanggal_post ?: 0L }
            "salary" -> {
                Comparator<Lowongan> { l1, l2 ->
                    val salary1 = parseSalaryToLong(l1.gaji)
                    val salary2 = parseSalaryToLong(l2.gaji)
                    compareValues(salary1, salary2)
                }
            }
            else -> return
        }

        if (ascending) {
            items.sortWith(comparator)
        } else {
            items.sortWith(comparator.reversed())
        }

        notifyDataSetChanged()
    }

    private fun parseSalaryToLong(salaryString: String?): Long {
        if (salaryString == null) return 0L

        val cleanString = salaryString.replace(Regex("[^0-9]"), "")

        return if (cleanString.isNotEmpty()) {
            try {
                cleanString.toLong()
            } catch (e: Exception) {
                0L
            }
        } else {
            0L
        }
    }
}