package com.example.kerjain

import android.content.Context
import android.net.Uri
import android.util.Log
import com.cloudinary.android.MediaManager
import com.cloudinary.android.callback.ErrorInfo
import com.cloudinary.android.callback.UploadCallback

object ImageHelper {

    fun init(context: Context) {
        try {
            val config = HashMap<String, Any>()
            config["cloud_name"] = "dunipee6j"
            config["secure"] = true
            MediaManager.init(context, config)

        } catch (e: Exception) {
        }
    }

    fun uploadImage(
        uri: Uri,
        folderName: String,
        presetName: String = "kerjain_app",
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        MediaManager.get().upload(uri)
            .unsigned(presetName)
            .option("folder", folderName)
            .callback(object : UploadCallback {

                override fun onStart(requestId: String) {
                    Log.d("ImageHelper", "Mulai upload ke Cloudinary...")
                }

                override fun onProgress(requestId: String, bytes: Long, totalBytes: Long) {
                }

                override fun onSuccess(requestId: String, resultData: Map<*, *>) {
                    val downloadUrl = resultData["secure_url"].toString()
                    Log.d("ImageHelper", "Upload Sukses: $downloadUrl")
                    onSuccess(downloadUrl)
                }

                override fun onError(requestId: String, error: ErrorInfo) {
                    Log.e("ImageHelper", "Error: ${error.description}")
                    onError(error.description)
                }

                override fun onReschedule(requestId: String, error: ErrorInfo) {
                }
            })
            .dispatch()
    }
}


