package com.example.kerjain.ui.company_profile

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.kerjain.WelcomeActivity
import com.example.kerjain.databinding.FragmentProfileCompanyBinding
import com.example.kerjain.ui.auth.LoginperusahaanActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class CompanyProfileFragment : Fragment() {

    private var _binding: FragmentProfileCompanyBinding? = null
    private val binding get() = _binding!!

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileCompanyBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        auth = Firebase.auth
        db = Firebase.firestore

        loadCompanyProfile()
        setupClickListeners()
    }

    private fun loadCompanyProfile() {
        val user = auth.currentUser
        if (user == null) {
            Toast.makeText(context, "Pengguna tidak ditemukan", Toast.LENGTH_SHORT).show()
            return
        }

        db.collection("perusahaan").document(user.uid).get()
            .addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    binding.tvCompanyName.text = document.getString("nama_perusahaan")
                    binding.tvCompanyEmail.text = document.getString("email")
                } else {
                    Toast.makeText(context, "Data profil tidak ditemukan.", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(context, "Gagal memuat profil: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun setupClickListeners() {
        binding.btnLogout.setOnClickListener {
            auth.signOut()
            val intent = Intent(activity, WelcomeActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            activity?.finish()
        }

        binding.btnEditProfile.setOnClickListener {
            Toast.makeText(context, "Fitur Edit Profil belum tersedia", Toast.LENGTH_SHORT).show()
        }
        binding.menuMyJobs.setOnClickListener {
            Toast.makeText(context, "Fitur Lowongan Saya belum tersedia", Toast.LENGTH_SHORT).show()
        }
        binding.menuAnalytics.setOnClickListener {
            Toast.makeText(context, "Fitur Analitik dan Laporan belum tersedia", Toast.LENGTH_SHORT).show()
        }
        binding.menuNotifications.setOnClickListener {
            Toast.makeText(context, "Fitur Notifikasi belum tersedia", Toast.LENGTH_SHORT).show()
        }
        binding.menuHelp.setOnClickListener {
            Toast.makeText(context, "Fitur Bantuan dan Dukungan belum tersedia", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
