package com.example.kerjain.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.JobDetailActivity
import com.example.kerjain.R
import com.example.kerjain.data.Lowongan
import com.google.firebase.firestore.FirebaseFirestore

class AllJobsFragment : Fragment() {

    private lateinit var rvAllJobs: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var emptyState: LinearLayout
    private lateinit var btnBack: ImageView
    private lateinit var adapter: JobAdapter
    private val db = FirebaseFirestore.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_all_jobs, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rvAllJobs = view.findViewById(R.id.rvAllJobs)
        progressBar = view.findViewById(R.id.progressBar)
        emptyState = view.findViewById(R.id.emptyState)
        btnBack = view.findViewById(R.id.btnBack)

        btnBack.setOnClickListener {
            findNavController().navigateUp()
        }

        setupRecyclerView()

        loadAllJobs()
    }

    private fun setupRecyclerView() {
        adapter = JobAdapter { lowongan ->
            val intent = Intent(requireContext(), JobDetailActivity::class.java)
            intent.putExtra("JOB_ID", lowongan.job_id)
            startActivity(intent)
        }
        rvAllJobs.layoutManager = LinearLayoutManager(context)
        rvAllJobs.adapter = adapter
    }

    private fun loadAllJobs() {
        progressBar.visibility = View.VISIBLE

        db.collection("lowongan")
            .get()
            .addOnSuccessListener { result ->
                progressBar.visibility = View.GONE

                if (result.isEmpty) {
                    emptyState.visibility = View.VISIBLE
                    rvAllJobs.visibility = View.GONE
                } else {
                    val jobList = result.documents.mapNotNull { doc ->
                        val job = doc.toObject(Lowongan::class.java)
                        job?.job_id = doc.id
                        job
                    }

                    adapter.setItems(jobList)
                    emptyState.visibility = View.GONE
                    rvAllJobs.visibility = View.VISIBLE
                }
            }
            .addOnFailureListener { e ->
                progressBar.visibility = View.GONE
                Toast.makeText(context, "Gagal memuat data: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}