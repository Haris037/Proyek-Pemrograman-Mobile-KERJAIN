package com.example.kerjain

import android.text.format.DateUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.data.Conversation
import com.google.firebase.firestore.FirebaseFirestore

class ChatHistoryAdapter(
    private val conversations: MutableList<Conversation>,
    private val currentUserId: String,
    private val onItemClick: (Conversation, String) -> Unit
) : RecyclerView.Adapter<ChatHistoryAdapter.ViewHolder>() {

    private val db = FirebaseFirestore.getInstance()

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvCompanyName: TextView = itemView.findViewById(R.id.tvCompanyName)
        val tvLastMessage: TextView = itemView.findViewById(R.id.tvLastMessage)
        val tvTime: TextView = itemView.findViewById(R.id.tvTime)
        val ivCompanyLogo: ImageView = itemView.findViewById(R.id.ivCompanyLogo)
        val tvUnreadBadge: TextView = itemView.findViewById(R.id.tvUnreadBadge)

        fun bind(item: Conversation) {
            tvLastMessage.text = item.lastMessage

            if (item.timestamp > 0) {
                tvTime.text = DateUtils.getRelativeTimeSpanString(
                    item.timestamp, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS
                )
            }

            tvUnreadBadge.visibility = View.GONE

            val otherUserId = item.participants.find { it != currentUserId }

            if (otherUserId != null) {
                itemView.setOnClickListener { onItemClick(item, otherUserId) }

                db.collection("perusahaan").document(otherUserId).get()
                    .addOnSuccessListener { doc ->
                        if (doc.exists()) {
                            tvCompanyName.text = doc.getString("nama_perusahaan") ?: "Tanpa Nama"
                            ivCompanyLogo.setImageResource(R.drawable.company_placeholder)
                        } else {
                            db.collection("pelamar").document(otherUserId).get()
                                .addOnSuccessListener { docPelamar ->
                                    if (docPelamar.exists()) {
                                        tvCompanyName.text = docPelamar.getString("nama") ?: "User"
                                        ivCompanyLogo.setImageResource(R.drawable.bg_avatar_circle)
                                    }
                                }
                        }
                    }
            } else {
                tvCompanyName.text = "Unknown User"
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_chat, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(conversations[position])
    }

    override fun getItemCount(): Int = conversations.size

    fun setItems(newItems: List<Conversation>) {
        conversations.clear()
        conversations.addAll(newItems)
        notifyDataSetChanged()
    }
}