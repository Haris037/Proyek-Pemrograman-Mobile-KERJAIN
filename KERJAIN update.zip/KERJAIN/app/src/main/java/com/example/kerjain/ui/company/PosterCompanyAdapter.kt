package com.example.kerjain.ui.company

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.kerjain.R
import com.example.kerjain.data.Poster
import com.example.kerjain.databinding.ItemPosterCompanyBinding

class PosterCompanyAdapter(private var posters: List<Poster>) : RecyclerView.Adapter<PosterCompanyAdapter.PosterViewHolder>() {

    fun updateData(newPosters: List<Poster>) {
        this.posters = newPosters
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PosterViewHolder {
        val binding = ItemPosterCompanyBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PosterViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PosterViewHolder, position: Int) {
        holder.bind(posters[position])
    }

    override fun getItemCount() = posters.size

    inner class PosterViewHolder(private val binding: ItemPosterCompanyBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(poster: Poster) {
            binding.tvPosterTitle.text = poster.title

            Glide.with(itemView.context)
                .load(poster.imageUrl)
                .placeholder(R.color.gray_input)
                .centerCrop()
                .into(binding.ivPoster)
        }
    }
}