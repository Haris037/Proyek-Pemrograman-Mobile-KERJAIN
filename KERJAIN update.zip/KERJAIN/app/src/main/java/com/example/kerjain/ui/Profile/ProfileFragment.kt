package com.example.kerjain.ui.profile

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.kerjain.R
import com.example.kerjain.WelcomeActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ProfileFragment : Fragment() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var tvProfileName: TextView
    private lateinit var tvProfileEmail: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_profile_pelamar, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        tvProfileName = view.findViewById(R.id.tvProfileName)
        tvProfileEmail = view.findViewById(R.id.tvProfileEmail)
        val btnLogout = view.findViewById<Button>(R.id.btnLogout)

        loadApplicantProfile()

        btnLogout.setOnClickListener {
            auth.signOut()

            val intent = Intent(activity, WelcomeActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            activity?.finish()
        }
    }

    private fun loadApplicantProfile() {
        val currentUser = auth.currentUser
        if (currentUser == null) return

        val uid = currentUser.uid

        db.collection("pelamar").document(uid).get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val name = document.getString("nama")
                    val email = document.getString("email")

                    tvProfileName.text = name ?: "Nama Pengguna"
                    tvProfileEmail.text = email ?: "email@contoh.com"
                }
            }
            .addOnFailureListener {
                context?.let { ctx ->
                    Toast.makeText(ctx, "Gagal memuat profil", Toast.LENGTH_SHORT).show()
                }
            }
    }
}