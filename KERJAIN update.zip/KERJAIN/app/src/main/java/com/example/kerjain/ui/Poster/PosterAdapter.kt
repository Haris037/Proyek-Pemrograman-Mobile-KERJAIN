package com.example.kerjain.ui.Poster

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.kerjain.R
import com.example.kerjain.data.Poster
import com.example.kerjain.databinding.ItemPosterPelamarBinding

class PosterAdapter(var posterList: List<Poster>) :
    RecyclerView.Adapter<PosterAdapter.PosterViewHolder>() {

    var onItemClick: ((Poster) -> Unit)? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PosterViewHolder {
        val binding = ItemPosterPelamarBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PosterViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PosterViewHolder, position: Int) {
        val poster = posterList[position]
        holder.bind(poster)
        holder.itemView.setOnClickListener { onItemClick?.invoke(poster) }
    }

    override fun getItemCount(): Int = posterList.size

    inner class PosterViewHolder(private val binding: ItemPosterPelamarBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(poster: Poster) {
            binding.tvPosterTitle.text = poster.title

            Glide.with(itemView.context)
                .load(poster.imageUrl)
                .placeholder(R.color.gray_input)
                .centerCrop()
                .into(binding.ivPoster)
        }
    }
}