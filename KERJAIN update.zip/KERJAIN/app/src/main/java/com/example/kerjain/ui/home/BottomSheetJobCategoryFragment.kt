package com.example.kerjain.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.R
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class BottomSheetJobCategoryFragment : BottomSheetDialogFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(
            R.layout.bottom_sheet_job_category,
            container,
            false
        )

        val rv = view.findViewById<RecyclerView>(R.id.rvCategory)
        rv.layoutManager = GridLayoutManager(requireContext(), 4)

        val categories = listOf(

            JobCategory("Admin", R.drawable.admin),
            JobCategory("Sekretaris", R.drawable.secretary),
            JobCategory("Customer Service", R.drawable.cs),

            JobCategory("Akuntansi", R.drawable.accounting),
            JobCategory("Keuangan", R.drawable.finance),

            JobCategory("Programmer", R.drawable.programmer),
            JobCategory("Web Developer", R.drawable.web),
            JobCategory("Mobile Developer", R.drawable.mobile),
            JobCategory("Data Analyst", R.drawable.data_analyst),

            JobCategory("Content Creator", R.drawable.content),
            JobCategory("Desain Grafis", R.drawable.design),
            JobCategory("Fotografer", R.drawable.camera),

            JobCategory("Guru", R.drawable.teacher),
            JobCategory("Dosen", R.drawable.lecturer),

            JobCategory("Perawat", R.drawable.nurse),
            JobCategory("Apoteker", R.drawable.pharmacy),

            JobCategory("Resepsionis", R.drawable.receptionist),
            JobCategory("Housekeeping", R.drawable.housekeeping),

            JobCategory("Chef", R.drawable.chef),
            JobCategory("Barista", R.drawable.barista),
            JobCategory("Waiter", R.drawable.waiter),

            JobCategory("Kurir", R.drawable.courier),
            JobCategory("Logistik", R.drawable.logistics),

            JobCategory("Security", R.drawable.security),
            JobCategory("Mekanik", R.drawable.mechanic),

            JobCategory("Quality Control", R.drawable.qc),
            JobCategory("Staff Gudang", R.drawable.warehouse),

            JobCategory("Freelancer", R.drawable.freelance),
        )

        rv.adapter = CategoryAdapter(categories) {
            // Anda bisa menambahkan logika di sini, misalnya meneruskan kategori yang dipilih
            dismiss()
        }

        return view
    }
}
