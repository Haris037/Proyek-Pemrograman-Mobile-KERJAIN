package com.example.kerjain

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import com.example.kerjain.databinding.FragmentAddJobBinding
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class AddJobFragment : Fragment() {

    private var _binding: FragmentAddJobBinding? = null
    private val binding get() = _binding!!

    private val auth = Firebase.auth
    private val firestore = Firebase.firestore

    private lateinit var mapLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        mapLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                result.data?.let {
                    val address = it.getStringExtra("address")
                    binding.etLocation.setText(address)
                }
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAddJobBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupSpinner()
        setupListeners()
    }

    private fun setupSpinner() {
        val jobTypes = arrayOf("Full-time", "Part-time", "Remote", "Internship")
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, jobTypes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spJobType.adapter = adapter
    }

    private fun setupListeners() {
        binding.btnPostJob.setOnClickListener {
            saveJobToFirestore()
        }

        binding.btnBack.setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        binding.btnSelectLocation.setOnClickListener {
            val intent = Intent(requireContext(), MapPickerActivity::class.java)
            mapLauncher.launch(intent)
        }
    }

    private fun saveJobToFirestore() {
        val jobName = binding.etJobName.text.toString().trim()
        val location = binding.etLocation.text.toString().trim()
        val jobType = binding.spJobType.selectedItem.toString()
        val salary = binding.etSalary.text.toString().trim()
        val criteria = binding.etCriteria.text.toString().trim()
        val description = binding.etDescription.text.toString().trim()
        val benefits = binding.etBenefits.text.toString().trim()

        if (!validateInput(jobName, location, salary, criteria, description)) {
            return
        }

        val user = auth.currentUser
        if (user == null) {
            Toast.makeText(requireContext(), "Error: Tidak ada perusahaan yang login", Toast.LENGTH_SHORT).show()
            return
        }
        val companyId = user.uid // Use Firebase UID as the company ID

        val fullDescription = buildString {
            append("Deskripsi Pekerjaan:\n")
            append(description)
            append("\n\nKriteria:\n")
            append(criteria)
            if (benefits.isNotEmpty()) {
                append("\n\nBenefit:\n")
                append(benefits)
            }
        }
        
        val jobData = hashMapOf(
            "perusahaan_id" to companyId,
            "judul" to jobName,
            "tipe" to jobType,
            "lokasi" to location,
            "gaji" to salary,
            "deskripsi" to fullDescription,
            "tanggal_post" to System.currentTimeMillis(),
            "category" to jobType
        )

        firestore.collection("lowongan")
            .add(jobData)
            .addOnSuccessListener {
                Toast.makeText(requireContext(), "Lowongan berhasil di-posting", Toast.LENGTH_SHORT).show()
                parentFragmentManager.popBackStack()
            }
            .addOnFailureListener { e ->
                Toast.makeText(requireContext(), "Gagal mem-posting lowongan: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun validateInput(jobName: String, location: String, salary: String, criteria: String, description: String): Boolean {
        if (jobName.isEmpty() || location.isEmpty() || salary.isEmpty() || criteria.isEmpty() || description.isEmpty()) {
            Toast.makeText(requireContext(), "Semua field wajib diisi (kecuali benefit)", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
