package com.example.kerjain.ui.lowongan

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.kerjain.data.Lowongan
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class LowonganViewModel : ViewModel() {

    private val _lowongans = MutableLiveData<List<Lowongan>>()
    val lowongans: LiveData<List<Lowongan>> get() = _lowongans

    private var cachedLowongans: List<Lowongan> = emptyList()
    private val db = Firebase.firestore

    init {
        loadLowongansFromFirestore()
    }

    private fun loadLowongansFromFirestore() {
        db.collection("lowongan").get()
            .addOnSuccessListener { result ->

                val lowonganList = result.documents.mapNotNull { doc ->
                    val lowongan = doc.toObject(Lowongan::class.java)
                    lowongan?.job_id = doc.id
                    lowongan
                }

                cachedLowongans = lowonganList
                _lowongans.value = lowonganList
            }
            .addOnFailureListener { exception ->
                Log.w("LowonganViewModel", "Error getting documents: ", exception)
                _lowongans.value = emptyList()
            }
    }

    fun filterLowongan(query: String) {
        if (query.isBlank()) {
            _lowongans.value = cachedLowongans
            return
        }

        val q = query.lowercase().trim()
        val filtered = cachedLowongans.filter { l ->
            l.judul.orEmpty().lowercase().contains(q) ||
                    l.lokasi.orEmpty().lowercase().contains(q) ||
                    l.gaji.orEmpty().lowercase().contains(q)
        }
        _lowongans.value = filtered
    }

    fun clearFilter() {
        _lowongans.value = cachedLowongans
    }

    fun applyFilter(selectedCategories: List<String>, minSalary: Int) {
        var filteredList = cachedLowongans

        if (selectedCategories.isNotEmpty()) {
            filteredList = filteredList.filter { lowongan ->
                selectedCategories.any { category -> lowongan.category?.equals(category, ignoreCase = true) == true }
            }
        }

        if (minSalary > 0) {
            filteredList = filteredList.filter { lowongan ->
                val salaryString = lowongan.gaji.orEmpty().replace("Rp. ", "").split(" - ").firstOrNull()
                val salary = salaryString?.filter { it.isDigit() }?.toIntOrNull()
                salary != null && salary >= minSalary
            }
        }

        _lowongans.value = filteredList
    }
}