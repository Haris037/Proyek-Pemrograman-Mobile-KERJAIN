package com.example.kerjain.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.databinding.ItemJobCategoryGridBinding

class CategoryAdapter(
    private var categories: List<JobCategory>,
    private val onItemClick: (JobCategory) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.ViewHolder>() {

    fun setItems(newCategories: List<JobCategory>) {
        this.categories = newCategories
        notifyDataSetChanged()
    }

    inner class ViewHolder(private val binding: ItemJobCategoryGridBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(category: JobCategory) {
            binding.ivCategoryIcon.setImageResource(category.iconResId)
            binding.tvCategoryName.text = category.name
            itemView.setOnClickListener { onItemClick(category) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemJobCategoryGridBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(categories[position])
    }

    override fun getItemCount(): Int = categories.size
}
