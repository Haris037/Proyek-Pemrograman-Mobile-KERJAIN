package com.example.kerjain.ui.auth

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.kerjain.R
import com.example.kerjain.ImageHelper
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class RegisterperusahaanActivity : AppCompatActivity() {

    // Views
    private lateinit var etCompanyName: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPhone: EditText
    private lateinit var etAddress: EditText
    private lateinit var etPassword: EditText
    private lateinit var etConfirmPassword: EditText
    private lateinit var btnRegister: Button
    private lateinit var imgLogo: ImageView
    private lateinit var tvUploadLogo: TextView
    private lateinit var progressBar: ProgressBar

    private lateinit var auth: FirebaseAuth

    private var selectedImageUri: Uri? = null

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedImageUri = uri
            imgLogo.setImageURI(uri)
            tvUploadLogo.text = "Ganti Logo"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registerperusahaan)

        auth = Firebase.auth
        ImageHelper.init(this)

        initViews()
        setupListeners()
    }

    private fun initViews() {
        etCompanyName = findViewById(R.id.etCompanyName)
        etEmail = findViewById(R.id.etEmail)
        etPhone = findViewById(R.id.etPhone)
        etAddress = findViewById(R.id.etAddress)
        etPassword = findViewById(R.id.etPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        btnRegister = findViewById(R.id.btnRegister)

        imgLogo = findViewById(R.id.imgLogo)
        tvUploadLogo = findViewById(R.id.tvUploadLogo)
        progressBar = findViewById(R.id.progressBar)
    }

    private fun setupListeners() {
        findViewById<View>(R.id.btnBack)?.setOnClickListener { finish() }

        imgLogo.setOnClickListener { pickImageLauncher.launch("image/*") }
        tvUploadLogo.setOnClickListener { pickImageLauncher.launch("image/*") }

        btnRegister.setOnClickListener {
            val companyName = etCompanyName.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val phone = etPhone.text.toString().trim()
            val address = etAddress.text.toString().trim()
            val password = etPassword.text.toString().trim()
            val confirmPassword = etConfirmPassword.text.toString().trim()

            if (validateInput(companyName, email, phone, address, password, confirmPassword)) {
                setLoading(true)
                registerUser(companyName, email, phone, address, password)
            }
        }
    }

    private fun registerUser(name: String, email: String, phone: String, address: String, pass: String) {
        auth.createUserWithEmailAndPassword(email, pass)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    if (user != null) {
                        uploadLogoAndSaveData(user.uid, name, email, phone, address)
                    }
                } else {
                    setLoading(false)
                    Toast.makeText(baseContext, "Registrasi Gagal: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                }
            }
    }

    private fun uploadLogoAndSaveData(userId: String, name: String, email: String, phone: String, address: String) {
        if (selectedImageUri != null) {
            ImageHelper.uploadImage(
                uri = selectedImageUri!!,
                folderName = "kerjain/logo_perusahaan",
                onSuccess = { downloadUrl ->
                    saveCompanyDataToFirestore(userId, name, email, phone, address, downloadUrl)
                },
                onError = { errorMsg ->
                    setLoading(false)
                    Toast.makeText(this, "Gagal upload logo: $errorMsg", Toast.LENGTH_SHORT).show()
                }
            )
        } else {
            saveCompanyDataToFirestore(userId, name, email, phone, address, null)
        }
    }

    private fun saveCompanyDataToFirestore(userId: String, name: String, email: String, phone: String, address: String, logoUrl: String?) {
        val db = Firebase.firestore

        val companyData = hashMapOf(
            "uid" to userId,
            "nama_perusahaan" to name,
            "email" to email,
            "alamat" to address,
            "telepon" to phone,
            "tipe_akun" to "perusahaan",
            "deskripsi" to "",
            "foto_profil_url" to logoUrl
        )

        db.collection("perusahaan").document(userId)
            .set(companyData)
            .addOnSuccessListener {
                setLoading(false)
                Log.d("REG_FLOW", "SUKSES: Data perusahaan tersimpan.")
                Toast.makeText(this, "Registrasi perusahaan berhasil!", Toast.LENGTH_SHORT).show()

                val intent = Intent(this, LoginperusahaanActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            }
            .addOnFailureListener { e ->
                setLoading(false)
                Toast.makeText(this, "Gagal menyimpan data database: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }

    private fun validateInput(
        companyName: String, email: String, phone: String, address: String,
        pass: String, confirmPass: String
    ): Boolean {
        if (companyName.isEmpty() || email.isEmpty() || phone.isEmpty() || address.isEmpty() || pass.isEmpty() || confirmPass.isEmpty()) {
            Toast.makeText(this, "Semua field harus diisi", Toast.LENGTH_SHORT).show()
            return false
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Email tidak valid", Toast.LENGTH_SHORT).show()
            return false
        }
        if (pass.length < 6) {
            Toast.makeText(this, "Password minimal 6 karakter", Toast.LENGTH_SHORT).show()
            return false
        }
        if (pass != confirmPass) {
            Toast.makeText(this, "Konfirmasi password tidak cocok", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }

    private fun setLoading(isLoading: Boolean) {
        progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        btnRegister.isEnabled = !isLoading
    }
}