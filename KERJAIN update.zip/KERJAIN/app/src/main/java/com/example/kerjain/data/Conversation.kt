package com.example.kerjain.data

data class Conversation(
    var id: String = "",
    val lastMessage: String = "",
    val timestamp: Long = 0L,
    val participants: List<String> = emptyList()
)