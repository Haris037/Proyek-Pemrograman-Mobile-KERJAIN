package com.example.kerjain.ui.Poster

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.kerjain.data.Poster
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class PosterViewModel : ViewModel() {

    private val _posters = MutableLiveData<List<Poster>>()
    val posters: LiveData<List<Poster>> get() = _posters

    private var cachedPosters: List<Poster> = emptyList()
    private val db = Firebase.firestore

    init {
        loadPostersFromFirestore()
    }

    private fun loadPostersFromFirestore() {
        db.collection("posters")
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { result, e ->
                if (e != null) {
                    Log.w("PosterViewModel", "Listen failed.", e)
                    _posters.value = emptyList()
                    return@addSnapshotListener
                }

                if (result != null) {
                    val posterList = result.documents.mapNotNull { document ->
                        document.toObject(Poster::class.java)
                    }
                    cachedPosters = posterList
                    _posters.value = posterList
                }
            }
    }

    fun filterPoster(query: String) {
        if (query.isBlank()) {
            _posters.value = cachedPosters
            return
        }

        val q = query.lowercase().trim()
        _posters.value = cachedPosters.filter {
            it.title.lowercase().contains(q)
        }
    }
}