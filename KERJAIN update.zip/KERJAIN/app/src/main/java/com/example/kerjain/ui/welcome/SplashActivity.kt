package com.example.kerjain.ui.welcome

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.kerjain.MainActivity
import com.example.kerjain.MainActivity2
import com.example.kerjain.R
import com.example.kerjain.WelcomeActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val splashTimeOut = 2000L

        Handler(Looper.getMainLooper()).postDelayed({
            checkLoginSession()
        }, splashTimeOut)
    }

    private fun checkLoginSession() {
        val auth = FirebaseAuth.getInstance()
        val currentUser = auth.currentUser

        if (currentUser != null) {
            checkUserRole(currentUser.uid)
        } else {
            goToWelcome()
        }
    }

    private fun checkUserRole(uid: String) {
        val db = FirebaseFirestore.getInstance()

        db.collection("pelamar").document(uid).get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    checkIfCompany(uid, db)
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Gagal memuat data user", Toast.LENGTH_SHORT).show()
                goToWelcome()
            }
    }

    private fun checkIfCompany(uid: String, db: FirebaseFirestore) {
        db.collection("perusahaan").document(uid).get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val intent = Intent(this, MainActivity2::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    FirebaseAuth.getInstance().signOut()
                    goToWelcome()
                }
            }
            .addOnFailureListener {
                goToWelcome()
            }
    }

    private fun goToWelcome() {
        val intent = Intent(this, WelcomeActivity::class.java)
        startActivity(intent)
        finish()
    }
}