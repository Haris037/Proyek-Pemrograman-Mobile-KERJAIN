package com.example.kerjain.ui.auth

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View // Tambahan import
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.kerjain.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class pelamarregisterActivity : AppCompatActivity() {

    private lateinit var etUsername: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPhone: EditText
    private lateinit var etPassword: EditText
    private lateinit var etConfirmPassword: EditText
    private lateinit var btnRegister: Button

    private lateinit var btnBack: View

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pelamarregister)
        Log.d("REG_PELAMAR_FIX", "Memulai alur registrasi pelamar satu langkah.")

        auth = Firebase.auth
        db = Firebase.firestore

        initViews()

        btnRegister.setOnClickListener {
            registerAndSaveApplicantInOneStep()
        }

        btnBack.setOnClickListener {
            finish()
        }
    }

    private fun initViews() {
        etUsername = findViewById(R.id.etUsername)
        etEmail = findViewById(R.id.etEmail)
        etPhone = findViewById(R.id.etPhone)
        etPassword = findViewById(R.id.etPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        btnRegister = findViewById(R.id.btnNext)

        btnBack = findViewById(R.id.btnBack)
    }

    private fun registerAndSaveApplicantInOneStep() {
        val username = etUsername.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val phone = etPhone.text.toString().trim()
        val password = etPassword.text.toString().trim()
        val confirm = etConfirmPassword.text.toString().trim()

        if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Nama, Email, dan Password harus diisi", Toast.LENGTH_SHORT).show()
            return
        }
        if (password != confirm) {
            Toast.makeText(this, "Password dan konfirmasi tidak cocok", Toast.LENGTH_SHORT).show()
            return
        }

        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    if (user != null) {
                        saveDataToFirestore(user.uid, username, email, phone)
                    } else {
                        Toast.makeText(this, "Gagal mendapatkan detail pengguna setelah registrasi.", Toast.LENGTH_LONG).show()
                    }
                } else {
                    Toast.makeText(baseContext, "Registrasi Gagal: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                }
            }
    }

    private fun saveDataToFirestore(userId: String, username: String, email: String, phone: String) {
        val pelamarData = hashMapOf(
            "nama" to username,
            "email" to email,
            "telepon" to phone,
            "tipe_akun" to "pelamar",
            "alamat" to "",
            "skill" to "",
            "pengalaman" to "",
            "foto" to ""
        )

        Log.d("REG_PELAMAR_FIX", "Menyimpan data ke koleksi 'pelamar'.")
        db.collection("pelamar").document(userId)
            .set(pelamarData)
            .addOnSuccessListener {
                Log.d("REG_PELAMAR_FIX", "SUKSES: Data pelamar disimpan. Mengarahkan ke login.")
                Toast.makeText(this, "Registrasi Pelamar Berhasil! Silakan Login.", Toast.LENGTH_LONG).show()

                auth.signOut()

                val intent = Intent(this, LoginPelamarActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            }
            .addOnFailureListener { e ->
                Log.e("REG_PELAMAR_FIX", "FATAL: Gagal menyimpan profil ke Firestore: ", e)
                Toast.makeText(this, "FATAL: Gagal menyimpan profil: ${e.message}", Toast.LENGTH_LONG).show()
                auth.currentUser?.delete()
            }
    }
}