package com.example.kerjain.data

import com.google.firebase.firestore.IgnoreExtraProperties
@IgnoreExtraProperties
data class Lowongan(
    var job_id: String? = null,
    val perusahaan_id: String? = null,
    val judul: String? = null,
    val tipe: String? = null,
    val lokasi: String? = null,
    val gaji: String? = null,
    val deskripsi: String? = null,
    val tanggal_post: Long? = null,
    val category: String? = null
)
