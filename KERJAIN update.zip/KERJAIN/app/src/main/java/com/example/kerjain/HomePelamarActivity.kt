package com.example.kerjain

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.commit
import com.example.kerjain.ui.home.HomePelamarFragment

class HomePelamarActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_pelamar)

        if (savedInstanceState == null) {
            supportFragmentManager.commit {
                replace(R.id.container_home_pelamar, HomePelamarFragment())
            }
        }
    }
}
