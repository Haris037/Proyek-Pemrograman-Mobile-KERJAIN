package com.example.kerjain.ui.home

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.GridLayoutManager
import com.example.kerjain.JobDetailActivity
import com.example.kerjain.MapPickerActivity
import com.example.kerjain.databinding.FragmentHomePelamarBinding

class HomeFragment : Fragment() {

    private var _binding: FragmentHomePelamarBinding? = null
    private val binding get() = _binding!!

    private val viewModel: HomeViewModel by viewModels()
    private lateinit var jobAdapter: JobAdapter

    private val mapResultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) {
            val selectedLocation = it.data?.getStringExtra("selected_location")
            if (selectedLocation != null) {
                binding.tvLocationSelected.text = selectedLocation
                viewModel.filterJobsByLocation(selectedLocation)
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomePelamarBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerViews()
        setupObservers()
        setupSearch()
        setupLocationPicker()

        binding.tvSeeAll.setOnClickListener {
            BottomSheetJobCategoryFragment().show(childFragmentManager, "BottomSheetJobCategoryFragment")
        }
    }

    private fun setupRecyclerViews() {
        jobAdapter = JobAdapter { lowongan ->
            val intent = Intent(requireContext(), JobDetailActivity::class.java).apply {
                lowongan.job_id?.let { putExtra("JOB_ID", it) }
            }
            if (intent.hasExtra("JOB_ID")) {
                startActivity(intent)
            }
        }
        binding.rvRecommendedJobs.apply {
            layoutManager = GridLayoutManager(requireContext(), 2)
            adapter = jobAdapter
        }

        val categoryAdapter = CategoryAdapter(HomeViewModel.DEFAULT_CATEGORIES) { selectedCategory ->
            viewModel.filterJobsByCategory(selectedCategory.name)
        }
        binding.rvJobCategories.apply {
            layoutManager = GridLayoutManager(requireContext(), 4)
            adapter = categoryAdapter
        }
    }

    private fun setupObservers() {
        viewModel.recommended.observe(viewLifecycleOwner) { jobs ->
             if (::jobAdapter.isInitialized) {
                jobAdapter.setItems(jobs)
            }
        }
    }

    private fun setupSearch() {
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { viewModel.filterRecommended(s.toString()) }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun setupLocationPicker() {
        binding.cardLocation.setOnClickListener {
            val intent = Intent(requireContext(), MapPickerActivity::class.java)
            mapResultLauncher.launch(intent)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
