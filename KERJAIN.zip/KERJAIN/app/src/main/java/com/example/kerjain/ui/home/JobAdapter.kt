package com.example.kerjain.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.data.Lowongan
import com.example.kerjain.databinding.ItemJobcardBinding

class JobAdapter(
    private val items: MutableList<Lowongan> = mutableListOf(),
    private val onClick: (Lowongan) -> Unit
) : RecyclerView.Adapter<JobAdapter.VH>() {

    inner class VH(val binding: ItemJobcardBinding) : RecyclerView.ViewHolder(binding.root) {
        init {
            binding.root.setOnClickListener {
                val pos = adapterPosition
                if (pos != RecyclerView.NO_POSITION) {
                    onClick(items[pos])
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemJobcardBinding.inflate(inflater, parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val job = items[position]
        // Menggunakan null-safe calls dan elvis operator untuk keamanan
        holder.binding.tvJobTitle.text = job.judul ?: "Judul tidak tersedia"
        holder.binding.tvCompanyName.text = "Perusahaan #${job.perusahaan_id ?: "N/A"}"
        holder.binding.tvLocation.text = job.lokasi ?: "Lokasi tidak tersedia"
        holder.binding.tvSalary.text = job.gaji ?: "Gaji tidak ditampilkan"
    }

    override fun getItemCount(): Int = items.size

    fun setItems(newItems: List<Lowongan>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    // --- PERBAIKAN UTAMA DI SINI: Logika sorting yang Null-Safe ---
    fun sort(criteria: String, ascending: Boolean) {
        val comparator = when (criteria) {
            "date" -> compareBy<Lowongan> { it.tanggal_post }
            "salary" -> {
                // Comparator kustom untuk mengurai dan membandingkan gaji
                Comparator<Lowongan> { l1, l2 ->
                    val salary1 = parseSalary(l1.gaji)
                    val salary2 = parseSalary(l2.gaji)
                    compareValues(salary1, salary2)
                }
            }
            else -> return // Kriteria tidak dikenal
        }

        if (ascending) {
            items.sortWith(comparator)
        } else {
            items.sortWith(comparator.reversed())
        }

        notifyDataSetChanged()
    }

    // Fungsi helper untuk mengurai gaji dari string
    private fun parseSalary(salaryString: String?): Int {
        if (salaryString == null) return 0
        // Logika ini mengasumsikan format seperti "Rp 5.000.000 - ..."
        // dan mengambil angka pertama. Anda mungkin perlu menyesuaikannya.
        return salaryString
            .substringAfter("Rp ")
            .split(" ")[0]
            .replace(".", "")
            .toIntOrNull() ?: 0
    }
}
