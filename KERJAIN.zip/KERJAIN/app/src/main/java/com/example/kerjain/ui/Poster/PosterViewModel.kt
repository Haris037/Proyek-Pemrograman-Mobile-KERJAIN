package com.example.kerjain.ui.Poster

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.kerjain.data.Lowongan
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class PosterViewModel : ViewModel() {

    private val _posters = MutableLiveData<List<Lowongan>>()
    val posters: LiveData<List<Lowongan>> get() = _posters

    private var cachedPosters: List<Lowongan> = emptyList()
    private val db = Firebase.firestore

    init {
        loadPostersFromFirestore()
    }

    private fun loadPostersFromFirestore() {
        db.collection("lowongan").get()
            .addOnSuccessListener { result ->
                val posterList = result.documents.mapNotNull { document ->
                    document.toObject(Lowongan::class.java)?.copy(job_id = document.id)
                }
                cachedPosters = posterList
                _posters.value = posterList
            }
            .addOnFailureListener { exception ->
                Log.w("PosterViewModel", "Error getting documents: ", exception)
                _posters.value = emptyList()
            }
    }

    fun filterPoster(query: String) {
        if (query.isBlank()) {
            _posters.value = cachedPosters
            return
        }

        val q = query.lowercase().trim()
        // --- PERBAIKAN DI SINI: Menggunakan orEmpty() untuk null safety ---
        _posters.value = cachedPosters.filter {
            it.judul.orEmpty().lowercase().contains(q) || 
            it.lokasi.orEmpty().lowercase().contains(q)
        }
    }
}
