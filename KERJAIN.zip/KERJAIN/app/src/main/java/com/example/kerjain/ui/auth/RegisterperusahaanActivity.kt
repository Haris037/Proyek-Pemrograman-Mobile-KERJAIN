package com.example.kerjain.ui.auth

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.kerjain.HomeCompanyActivity
import com.example.kerjain.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class RegisterperusahaanActivity : AppCompatActivity() {

    private lateinit var etCompanyName: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPhone: EditText
    private lateinit var etAddress: EditText
    private lateinit var etPassword: EditText
    private lateinit var etConfirmPassword: EditText
    private lateinit var btnRegister: Button

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registerperusahaan)

        auth = Firebase.auth

        initViews()
        setupListeners()
    }

    private fun initViews() {
        etCompanyName = findViewById(R.id.etCompanyName)
        etEmail = findViewById(R.id.etEmail)
        etPhone = findViewById(R.id.etPhone)
        etAddress = findViewById(R.id.etAddress)
        etPassword = findViewById(R.id.etPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        btnRegister = findViewById(R.id.btnRegister)
    }

    private fun setupListeners() {
        btnRegister.setOnClickListener {
            val companyName = etCompanyName.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val phone = etPhone.text.toString().trim()
            val address = etAddress.text.toString().trim()
            val password = etPassword.text.toString().trim()
            val confirmPassword = etConfirmPassword.text.toString().trim()

            if (validateInput(companyName, email, phone, address, password, confirmPassword)) {
                registerAndSaveCompany(companyName, email, phone, address, password)
            }
        }
    }

    private fun validateInput(
        companyName: String, email: String, phone: String, address: String,
        pass: String, confirmPass: String
    ): Boolean {
        // Validation logic remains the same
        if (companyName.isEmpty() || email.isEmpty() || phone.isEmpty() || address.isEmpty() || pass.isEmpty() || confirmPass.isEmpty()) {
            Toast.makeText(this, "Semua field harus diisi", Toast.LENGTH_SHORT).show()
            return false
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Email tidak valid", Toast.LENGTH_SHORT).show()
            return false
        }
        if (pass.length < 6) {
            Toast.makeText(this, "Password minimal 6 karakter", Toast.LENGTH_SHORT).show()
            return false
        }
        if (pass != confirmPass) {
            Toast.makeText(this, "Password dan konfirmasi password tidak cocok", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }

    private fun registerAndSaveCompany(name: String, email: String, phone: String, address: String, pass: String) {
        auth.createUserWithEmailAndPassword(email, pass)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    if (user != null) {
                        saveCompanyDataToFirestore(user.uid, name, email, phone, address)
                    } else {
                        Toast.makeText(this, "Registrasi gagal, coba lagi.", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(baseContext, "Registrasi Gagal: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                }
            }
    }

    private fun saveCompanyDataToFirestore(userId: String, name: String, email: String, phone: String, address: String) {
        val db = Firebase.firestore
        // --- SOLUSI ANDA DITERAPKAN DI SINI ---
        val companyData = hashMapOf(
            "nama_perusahaan" to name,
            "email" to email,
            "alamat" to address,
            "telepon" to phone,
            "tipe_akun" to "perusahaan", // Menambahkan tipe akun secara eksplisit
            "deskripsi" to ""
        )

        db.collection("perusahaan").document(userId)
            .set(companyData)
            .addOnSuccessListener { 
                Log.d("REG_FLOW", "SUKSES: Data perusahaan disimpan dengan tipe_akun='perusahaan'.")
                Toast.makeText(this, "Registrasi perusahaan berhasil", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, HomeCompanyActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
             }
            .addOnFailureListener { e -> 
                 Toast.makeText(this, "Gagal menyimpan data perusahaan: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }
}
