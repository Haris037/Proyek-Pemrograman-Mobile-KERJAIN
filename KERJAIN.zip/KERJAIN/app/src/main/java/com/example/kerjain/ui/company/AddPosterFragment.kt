package com.example.kerjain.ui.company

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.kerjain.databinding.FragmentAddPosterBinding

class AddPosterFragment : Fragment() {

    private var _binding: FragmentAddPosterBinding? = null
    private val binding get() = _binding!!

    private var imageUri: Uri? = null

    companion object {
        private const val REQUEST_CODE_IMAGE_PICKER = 100
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAddPosterBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnBack.setOnClickListener {
            findNavController().navigateUp()
        }

        binding.btnUploadPoster.setOnClickListener {
            openImagePicker()
        }

        binding.btnPostPoster.setOnClickListener {
            publishPoster()
        }
    }

    private fun openImagePicker() {
        Intent(Intent.ACTION_PICK).also { 
            it.type = "image/*"
            startActivityForResult(it, REQUEST_CODE_IMAGE_PICKER)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && requestCode == REQUEST_CODE_IMAGE_PICKER) {
            imageUri = data?.data
            binding.imgPoster.setImageURI(imageUri)
        }
    }

    private fun publishPoster() {
        val title = binding.etPosterTitle.text.toString().trim()

        if (imageUri == null) {
            Toast.makeText(context, "Please select an image", Toast.LENGTH_SHORT).show()
            return
        }

        // TODO: Implement the logic to upload the image and save the poster data to Firebase
        
        Toast.makeText(context, "Poster published successfully", Toast.LENGTH_SHORT).show()
        findNavController().navigateUp()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
