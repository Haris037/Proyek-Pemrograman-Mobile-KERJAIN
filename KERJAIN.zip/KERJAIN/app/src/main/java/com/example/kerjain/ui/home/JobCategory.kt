package com.example.kerjain.ui.home

import androidx.annotation.DrawableRes

data class JobCategory(val name: String, @DrawableRes val iconResId: Int)
