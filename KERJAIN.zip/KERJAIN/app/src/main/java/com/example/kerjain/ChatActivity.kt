package com.example.kerjain

import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.data.Message
import com.google.android.material.appbar.MaterialToolbar
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class ChatActivity : AppCompatActivity() {

    private lateinit var toolbar: MaterialToolbar
    private lateinit var rvChatMessages: RecyclerView
    private lateinit var etMessage: EditText
    private lateinit var btnSendMessage: ImageButton

    private val auth = Firebase.auth
    private val db = Firebase.firestore
    private lateinit var messageAdapter: MessageAdapter

    private var recipientId: String? = null
    private var recipientName: String? = null
    private var senderId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        recipientId = intent.getStringExtra("RECIPIENT_ID")
        recipientName = intent.getStringExtra("RECIPIENT_NAME")
        senderId = auth.currentUser?.uid

        if (recipientId == null || senderId == null) {
            Toast.makeText(this, "ID pengguna atau penerima tidak valid.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        bindViews()
        setupToolbar()
        setupRecyclerView()
        setupListeners()
        listenForMessages()
    }

    private fun bindViews() {
        toolbar = findViewById(R.id.toolbar)
        rvChatMessages = findViewById(R.id.rvChatMessages)
        etMessage = findViewById(R.id.etMessage)
        btnSendMessage = findViewById(R.id.btnSendMessage)
    }

    private fun setupToolbar() {
        toolbar.title = recipientName ?: "Chat"
        toolbar.setNavigationOnClickListener { finish() }
    }

    private fun setupRecyclerView() {
        messageAdapter = MessageAdapter(mutableListOf(), senderId!!)
        rvChatMessages.apply {
            adapter = messageAdapter
            layoutManager = LinearLayoutManager(this@ChatActivity).apply {
                stackFromEnd = true
            }
        }
    }

    private fun setupListeners() {
        btnSendMessage.setOnClickListener {
            val messageText = etMessage.text.toString().trim()
            if (messageText.isNotEmpty()) {
                sendMessage(messageText)
            }
        }
    }

    private fun getChatRoomId(user1: String, user2: String): String {
        return if (user1 < user2) "${user1}_${user2}" else "${user2}_${user1}"
    }

    private fun listenForMessages() {
        val chatRoomId = getChatRoomId(senderId!!, recipientId!!)
        db.collection("chats").document(chatRoomId).collection("messages")
            .orderBy("timestamp")
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Toast.makeText(this, "Gagal memuat pesan.", Toast.LENGTH_SHORT).show()
                    return@addSnapshotListener
                }

                val messages = snapshot?.toObjects(Message::class.java)
                if (messages != null) {
                    messageAdapter.updateMessages(messages)
                    rvChatMessages.scrollToPosition(messageAdapter.itemCount - 1)
                }
            }
    }

    private fun sendMessage(messageText: String) {
        val chatRoomId = getChatRoomId(senderId!!, recipientId!!)

        val message = Message(
            senderId = senderId!!,
            receiverId = recipientId!!,
            message = messageText,
            timestamp = System.currentTimeMillis()
        )

        db.collection("chats").document(chatRoomId).collection("messages")
            .add(message)
            .addOnSuccessListener {
                etMessage.text.clear()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Pesan gagal dikirim.", Toast.LENGTH_SHORT).show()
            }
    }
}
