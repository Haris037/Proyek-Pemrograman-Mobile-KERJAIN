package com.example.kerjain.data

import com.google.firebase.firestore.IgnoreExtraProperties

// Annotation ini sangat penting. Ini memberitahu Firestore untuk mengabaikan
// field tambahan di database yang tidak ada di data class ini.
@IgnoreExtraProperties
data class Lowongan(
    // Semua properti dibuat nullable (bisa null) untuk mencegah crash
    // jika ada field yang tidak ada di dokumen Firestore.
    val job_id: String? = null,
    val perusahaan_id: String? = null,
    val judul: String? = null,
    val tipe: String? = null,
    val lokasi: String? = null,
    val gaji: String? = null,
    val deskripsi: String? = null,
    val tanggal_post: Long? = null,
    val category: String? = null
)
