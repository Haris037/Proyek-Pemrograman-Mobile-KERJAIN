package com.example.kerjain

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.kerjain.data.Lamaran
import com.example.kerjain.data.Lowongan
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObject
import com.google.firebase.ktx.Firebase
import java.text.SimpleDateFormat
import java.util.*

class JobDetailActivity : AppCompatActivity() {

    private val firestore = Firebase.firestore
    private val auth = Firebase.auth

    private var jobId: String? = null
    private var pelamarId: String? = null
    private var companyId: String? = null // To store company id for chat

    private lateinit var btnBack: ImageView
    private lateinit var btnShare: ImageView
    private lateinit var btnBookmark: ImageView
    private lateinit var btnApply: Button
    private lateinit var btnOpenMap: Button
    private lateinit var btnChat: ImageButton

    private lateinit var ivCompanyLogo: ImageView
    private lateinit var tvJobTitle: TextView
    private lateinit var tvCompanyName: TextView
    private lateinit var tvLocation: TextView
    private lateinit var tvJobType: TextView
    private lateinit var tvSalary: TextView
    private lateinit var tvPostedDate: TextView
    private lateinit var tvJobDescription: TextView
    private lateinit var tvCompanyAddress: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_job_detail)

        jobId = intent.getStringExtra("JOB_ID")
        pelamarId = auth.currentUser?.uid

        bindViews()
        loadJobDetail()
        setupListeners()
    }

    private fun bindViews() {
        btnBack = findViewById(R.id.btnBack)
        btnShare = findViewById(R.id.btnShare)
        btnBookmark = findViewById(R.id.btnBookmark)
        btnApply = findViewById(R.id.btnApply)
        btnOpenMap = findViewById(R.id.btnOpenMap)
        btnChat = findViewById(R.id.btnChat)

        ivCompanyLogo = findViewById(R.id.ivCompanyLogo)
        tvJobTitle = findViewById(R.id.tvJobTitle)
        tvCompanyName = findViewById(R.id.tvCompanyName)
        tvLocation = findViewById(R.id.tvLocation)
        tvJobType = findViewById(R.id.tvJobType)
        tvSalary = findViewById(R.id.tvSalary)
        tvPostedDate = findViewById(R.id.tvPostedDate)
        tvJobDescription = findViewById(R.id.tvJobDescription)
        tvCompanyAddress = findViewById(R.id.tvCompanyAddress)
    }

    private fun setupListeners() {
        btnBack.setOnClickListener { finish() }

        btnShare.setOnClickListener {
            Toast.makeText(this, "Fitur Share belum tersedia", Toast.LENGTH_SHORT).show()
        }

        btnBookmark.setOnClickListener {
            Toast.makeText(this, "Disimpan (belum diimplementasi)", Toast.LENGTH_SHORT).show()
        }

        btnApply.setOnClickListener {
            applyToJob()
        }

        btnOpenMap.setOnClickListener {
            val address = tvCompanyAddress.text.toString()
            if (address.isNotEmpty() && address != "Alamat tidak tersedia") {
                val gmmIntentUri = Uri.parse("geo:0,0?q=$address")
                val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                mapIntent.setPackage("com.google.android.apps.maps")
                if (mapIntent.resolveActivity(packageManager) != null) {
                    startActivity(mapIntent)
                } else {
                    Toast.makeText(this, "Google Maps tidak terinstall.", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Alamat tidak tersedia untuk dibuka di peta.", Toast.LENGTH_SHORT).show()
            }
        }

        btnChat.setOnClickListener {
            if (companyId != null) {
                val intent = Intent(this, ChatActivity::class.java)
                intent.putExtra("RECIPIENT_ID", companyId)
                 intent.putExtra("RECIPIENT_NAME", tvCompanyName.text.toString()) // Pass company name
                startActivity(intent)
            } else {
                Toast.makeText(this, "Tidak dapat memulai chat, ID perusahaan tidak ditemukan.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadJobDetail() {
        if (jobId == null) {
            Toast.makeText(this, "ID Lowongan tidak valid", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        firestore.collection("lowongan").document(jobId!!).get()
            .addOnSuccessListener { document ->
                val job = document.toObject<Lowongan>()
                if (job != null) {
                    updateUi(job.copy(job_id = document.id))
                } else {
                    Toast.makeText(this, "Lowongan tidak ditemukan", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Gagal memuat data: ${e.message}", Toast.LENGTH_SHORT).show()
                finish()
            }
    }

    private fun updateUi(job: Lowongan) {
        tvJobTitle.text = job.judul ?: "Judul tidak tersedia"
        tvLocation.text = job.lokasi ?: "Lokasi tidak tersedia"
        tvJobType.text = job.tipe ?: "Tipe pekerjaan tidak spesifik"
        tvSalary.text = job.gaji ?: "Gaji tidak ditampilkan"
        tvJobDescription.text = job.deskripsi ?: "Deskripsi tidak tersedia."

        job.tanggal_post?.let { timestamp ->
            val date = Date(timestamp)
            tvPostedDate.text = "Diposting pada " + SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(date)
        } ?: run {
            tvPostedDate.text = "Tanggal posting tidak tersedia"
        }

        job.perusahaan_id?.let { id ->
            this.companyId = id
            if (id.isNotEmpty()) {
                 firestore.collection("perusahaan").document(id).get()
                    .addOnSuccessListener { companyDoc ->
                        tvCompanyName.text = companyDoc.getString("nama_perusahaan") ?: "Nama Perusahaan Tidak Tersedia"
                        tvCompanyAddress.text = companyDoc.getString("alamat") ?: "Alamat tidak tersedia"
                    }
                    .addOnFailureListener {
                        tvCompanyName.text = "Info perusahaan gagal dimuat"
                        tvCompanyAddress.text = "Alamat tidak tersedia"
                    }
            } else {
                 tvCompanyName.text = "Perusahaan tidak terhubung"
                 tvCompanyAddress.text = "Alamat tidak tersedia"
            }
        } ?: run {
            tvCompanyName.text = "Perusahaan tidak terhubung"
            tvCompanyAddress.text = "Alamat tidak tersedia"
        }
        
        ivCompanyLogo.setImageResource(R.drawable.perusahaan) // Placeholder image
    }

    private fun applyToJob() {
        if (pelamarId == null || jobId == null) {
            Toast.makeText(this, "Akun pelamar atau ID lowongan tidak ditemukan", Toast.LENGTH_SHORT).show()
            return
        }

        val lamaranData = hashMapOf(
            "pelamar_id" to pelamarId,
            "job_id" to jobId,
            "status_lamaran" to "Menunggu",
            "tanggal_lamaran" to System.currentTimeMillis()
        )

        firestore.collection("lamaran").add(lamaranData)
            .addOnSuccessListener {
                Toast.makeText(this, "Lamaran berhasil dikirim", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                 Toast.makeText(this, "Gagal mengirim lamaran: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
