package com.example.kerjain.ui.Poster

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.data.Lowongan
import com.example.kerjain.databinding.ItemPosterBinding

class PosterAdapter(var lowonganList: List<Lowongan>) :
    RecyclerView.Adapter<PosterAdapter.PosterViewHolder>() {

    var onItemClick: ((Lowongan) -> Unit)? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PosterViewHolder {
        val binding = ItemPosterBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PosterViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PosterViewHolder, position: Int) {
        val lowongan = lowonganList[position]
        holder.bind(lowongan)
        holder.itemView.setOnClickListener { onItemClick?.invoke(lowongan) }
    }

    override fun getItemCount(): Int = lowonganList.size

    inner class PosterViewHolder(private val binding: ItemPosterBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(lowongan: Lowongan) {
            binding.tvJobTitle.text = lowongan.judul
            binding.tvCompanyName.text = lowongan.perusahaan_id // Menggunakan perusahaan_id untuk sementara
            binding.tvLocation.text = lowongan.lokasi
        }
    }
}
