package com.example.kerjain.ui.home

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.GridLayoutManager
import com.example.kerjain.JobDetailActivity
import com.example.kerjain.databinding.FragmentHomePelamarBinding

class HomePelamarFragment : Fragment() {

    private var _binding: FragmentHomePelamarBinding? = null
    private val binding get() = _binding!!

    private val viewModel: HomeViewModel by viewModels()
    private lateinit var jobAdapter: JobAdapter
    private lateinit var categoryAdapter: CategoryAdapter
    private var isCategoriesExpanded = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        parentFragmentManager.setFragmentResultListener("location_request", this) { _, bundle ->
            val selectedLocation = bundle.getString("selected_location")
            if (selectedLocation != null) {
                binding.tvLocationSelected.text = selectedLocation
                viewModel.filterJobsByLocation(selectedLocation)
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomePelamarBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerViews()
        setupObservers()
        setupSearch()
        setupLocationPicker()

        binding.tvSeeAll.setOnClickListener {
            isCategoriesExpanded = !isCategoriesExpanded
            updateCategories()
        }
        updateCategories()
    }

    private fun setupRecyclerViews() {
        jobAdapter = JobAdapter { lowongan ->
            val intent = Intent(requireContext(), JobDetailActivity::class.java).apply {
                lowongan.job_id?.let { putExtra("JOB_ID", it) }
            }
            if (intent.hasExtra("JOB_ID")) {
                startActivity(intent)
            }
        }
        binding.rvRecommendedJobs.apply {
            layoutManager = GridLayoutManager(requireContext(), 2)
            adapter = jobAdapter
        }

        categoryAdapter = CategoryAdapter(emptyList()) { selectedCategory ->
            viewModel.filterJobsByCategory(selectedCategory.name)
        }
        binding.rvJobCategories.apply {
            layoutManager = GridLayoutManager(requireContext(), 4)
            adapter = categoryAdapter
        }
    }

    private fun updateCategories() {
        val allCategories = HomeViewModel.DEFAULT_CATEGORIES
        val categoriesToShow = if (isCategoriesExpanded) allCategories else allCategories.take(8)
        categoryAdapter.setItems(categoriesToShow)
        binding.tvSeeAll.text = if (isCategoriesExpanded) "Tutup" else "Lainnya"
    }

    private fun setupObservers() {
        viewModel.recommended.observe(viewLifecycleOwner) { jobs ->
             if (::jobAdapter.isInitialized) {
                jobAdapter.setItems(jobs)
            }
        }
    }

    private fun setupSearch() {
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { viewModel.filterRecommended(s.toString()) }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun setupLocationPicker() {
        binding.cardLocation.setOnClickListener {
            LocationFilterBottomSheet().show(childFragmentManager, "LocationFilterBottomSheet")
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
