package com.example.kerjain.ui.company

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.kerjain.R
import com.example.kerjain.databinding.FragmentPosterCompanyBinding

class PosterCompanyFragment : Fragment() {

    private var _binding: FragmentPosterCompanyBinding? = null
    private val binding get() = _binding!!

    // TODO: Replace with actual data from Firebase
    private val posters = emptyList<Poster>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPosterCompanyBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnCreatePoster.setOnClickListener {
            findNavController().navigate(R.id.action_navigation_poster_company_to_addPosterFragment)
        }

        setupRecyclerView()
    }

    private fun setupRecyclerView() {
        if (posters.isEmpty()) {
            binding.emptyState.visibility = View.VISIBLE
            binding.rvPosters.visibility = View.GONE
        } else {
            binding.emptyState.visibility = View.GONE
            binding.rvPosters.visibility = View.VISIBLE
            binding.rvPosters.layoutManager = LinearLayoutManager(context)
            binding.rvPosters.adapter = PosterCompanyAdapter(posters)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
