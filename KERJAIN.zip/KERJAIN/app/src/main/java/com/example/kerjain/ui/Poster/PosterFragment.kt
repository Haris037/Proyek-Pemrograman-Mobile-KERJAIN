package com.example.kerjain.ui.Poster

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.kerjain.JobDetailActivity
import com.example.kerjain.data.Lowongan
import com.example.kerjain.databinding.FragmentPosterPelamarBinding
import com.example.kerjain.ui.Poster.PosterAdapter
import com.example.kerjain.ui.Poster.PosterViewModel

class PosterFragment : Fragment() {

    private var _binding: FragmentPosterPelamarBinding? = null
    private val binding get() = _binding!!

    private lateinit var posterViewModel: PosterViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPosterPelamarBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        posterViewModel = ViewModelProvider(this)[PosterViewModel::class.java]

        val adapter = PosterAdapter(emptyList())
        adapter.onItemClick = { lowongan: Lowongan ->
            val intent = Intent(requireActivity(), JobDetailActivity::class.java).apply {
                putExtra("JOB_ID", lowongan.job_id)
            }
            startActivity(intent)
        }

        binding.rvPosters.adapter = adapter
        binding.rvPosters.layoutManager = LinearLayoutManager(context)

        posterViewModel.posters.observe(viewLifecycleOwner) { it ->
            val posterAdapter = binding.rvPosters.adapter as? PosterAdapter
            if (it.isNotEmpty() && posterAdapter != null) {
                posterAdapter.lowonganList = it
                posterAdapter.notifyDataSetChanged()
                binding.emptyState.visibility = View.GONE
                binding.rvPosters.visibility = View.VISIBLE
            } else {
                binding.emptyState.visibility = View.VISIBLE
                binding.rvPosters.visibility = View.GONE
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
