package com.example.kerjain.ui.home

import android.graphics.Color
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.R

class HomeCategoryAdapter(
    private val categories: List<String>,
    private val onCategoryClick: (String?) -> Unit
) : RecyclerView.Adapter<HomeCategoryAdapter.ViewHolder>() {

    private var selectedPosition = -1

    inner class ViewHolder(val textView: TextView) : RecyclerView.ViewHolder(textView) {
        fun bind(category: String, isSelected: Boolean) {
            textView.text = category
            if (isSelected) {
                textView.setBackgroundResource(R.drawable.bg_category_selected)
                textView.setTextColor(Color.WHITE)
                textView.setTypeface(null, Typeface.BOLD)
            } else {
                textView.setBackgroundResource(R.drawable.bg_category_unselected)
                textView.setTextColor(Color.BLACK)
                textView.setTypeface(null, Typeface.NORMAL)
            }

            itemView.setOnClickListener {
                if (selectedPosition == adapterPosition) {
                    // Deselect if the same item is clicked again
                    selectedPosition = -1
                    notifyItemChanged(adapterPosition)
                    onCategoryClick(null)
                } else {
                    val oldPosition = selectedPosition
                    selectedPosition = adapterPosition
                    if (oldPosition != -1) {
                        notifyItemChanged(oldPosition)
                    }
                    notifyItemChanged(selectedPosition)
                    onCategoryClick(category)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_home_category, parent, false) as TextView
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(categories[position], selectedPosition == position)
    }

    override fun getItemCount(): Int = categories.size
}
