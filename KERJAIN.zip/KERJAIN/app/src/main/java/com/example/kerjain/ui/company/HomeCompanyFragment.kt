package com.example.kerjain.ui.company

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.R

class HomeCompanyFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home_company, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val btnAddJob = view.findViewById<Button>(R.id.btnAddJob)
        val tvSeeAllPosters = view.findViewById<TextView>(R.id.tvSeeAllPosters)
        val tvSeeAllWorkers = view.findViewById<TextView>(R.id.tvSeeAllWorkers)
        val rvCompanyPosters = view.findViewById<RecyclerView>(R.id.rvCompanyPosters)
        val rvWorkers = view.findViewById<RecyclerView>(R.id.rvWorkers)

        btnAddJob.setOnClickListener {
            findNavController().navigate(R.id.action_navigation_home_company_to_addJobFragment)
        }

        tvSeeAllPosters.setOnClickListener {
            findNavController().navigate(R.id.action_navigation_home_company_to_allPostersFragment)
        }

        tvSeeAllWorkers.setOnClickListener {
            findNavController().navigate(R.id.action_navigation_home_company_to_allApplicantsFragment)
        }

        // TODO: Set up RecyclerView adapters
        // rvCompanyPosters.adapter = ...
        // rvWorkers.adapter = ...

        // TODO: Update counts from ViewModel
        // val tvOpenPositions = view.findViewById<TextView>(R.id.tvOpenPositions)
        // val tvApplicants = view.findViewById<TextView>(R.id.tvApplicants)
        // val tvMessages = view.findViewById<TextView>(R.id.tvMessages)
    }
}
