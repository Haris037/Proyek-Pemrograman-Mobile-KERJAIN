package com.example.kerjain.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.R
import java.util.Locale

class LocationAdapter(
    private var locations: List<String>,
    private val onLocationClick: (String) -> Unit
) : RecyclerView.Adapter<LocationAdapter.ViewHolder>(), Filterable {

    private var filteredLocations = locations

    inner class ViewHolder(val textView: TextView) : RecyclerView.ViewHolder(textView) {
        fun bind(location: String) {
            textView.text = location
            itemView.setOnClickListener { onLocationClick(location) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_location, parent, false) as TextView
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(filteredLocations[position])
    }

    override fun getItemCount(): Int = filteredLocations.size

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val charString = constraint?.toString()?.lowercase(Locale.ROOT) ?: ""
                filteredLocations = if (charString.isEmpty()) {
                    locations
                } else {
                    locations.filter { it.lowercase(Locale.ROOT).contains(charString) }
                }
                val filterResults = FilterResults()
                filterResults.values = filteredLocations
                return filterResults
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                filteredLocations = results?.values as? List<String> ?: emptyList()
                notifyDataSetChanged()
            }
        }
    }
}
