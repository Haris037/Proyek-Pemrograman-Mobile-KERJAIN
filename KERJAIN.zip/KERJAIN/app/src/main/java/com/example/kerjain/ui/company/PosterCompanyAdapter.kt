package com.example.kerjain.ui.company

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.kerjain.databinding.ItemPosterCompanyBinding

class PosterCompanyAdapter(private val posters: List<Poster>) : RecyclerView.Adapter<PosterCompanyAdapter.PosterViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PosterViewHolder {
        val binding = ItemPosterCompanyBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PosterViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PosterViewHolder, position: Int) {
        holder.bind(posters[position])
    }

    override fun getItemCount() = posters.size

    inner class PosterViewHolder(private val binding: ItemPosterCompanyBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(poster: Poster) {
            // TODO: Load image using a library like Glide or Picasso
            // binding.ivPoster.setImageResource(poster.imageUrl)
            binding.tvPosterTitle.text = poster.title
        }
    }
}

data class Poster(val imageUrl: String, val title: String)
